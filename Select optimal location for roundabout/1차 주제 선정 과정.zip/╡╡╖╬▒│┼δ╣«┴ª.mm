<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1596437836808" ID="ID_1362670188" MODIFIED="1596524020383">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#46020;&#47196;&#44368;&#53685;&#47928;&#51228;
    </p>
    <p>
      (!&#47484; &#46384;&#46972;&#44032;&#49464;&#50836;)
    </p>
  </body>
</html>
</richcontent>
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1596441230877" ID="ID_1090594038" MODIFIED="1596441235072" POSITION="right" TEXT="&#xad50;&#xd1b5; &#xccb4;&#xc99d;">
<node CREATED="1596441323608" ID="ID_1589183988" MODIFIED="1596441325765" TEXT="&#xc815;&#xc758;">
<node CREATED="1596453485064" ID="ID_370241580" MODIFIED="1596453486120" TEXT="&#xad50;&#xd1b5; &#xccb4;&#xc99d;(&#x4ea4;&#x901a;&#x6eef;&#x75c7;)&#xc740; &#xc790;&#xb3d9;&#xcc28;, &#xbc84;&#xc2a4;, &#xd2b8;&#xb7ed; &#xb4f1;&#xacfc; &#xac19;&#xc740; &#xad50;&#xd1b5;&#xc218;&#xb2e8;&#xc774; &#xb9ce;&#xc544; &#xae38;&#xc774; &#xb9c9;&#xd788;&#xb294; &#xac83;&#xc744; &#xb9d0;&#xd55c;&#xb2e4;."/>
</node>
<node CREATED="1596441326008" ID="ID_1803354883" MODIFIED="1596443687087" TEXT="&#xc6d0;&#xc778;">
<node CREATED="1596442509267" ID="ID_577112771" MODIFIED="1596442743702" TEXT="&#xbd88;&#xbc95; &#xc8fc;&#xc815;&#xcc28;">
<node CREATED="1596453633794" ID="ID_1105075590" MODIFIED="1596453634753" TEXT="&#xbd88;&#xbc95;&#xc8fc;&#xc815;&#xcc28; &#xd604;&#xd669; 2013&#xb144; 22,228&#xac74; -&gt; 2017&#xb144; 51,489&#xac74;"/>
</node>
<node CREATED="1596442514921" ID="ID_928619708" MODIFIED="1596442553213" TEXT="&#xcc28;&#xb7c9; &#xb300;&#xc218; &#xc99d;&#xac00;">
<node CREATED="1596453572744" ID="ID_266321562" MODIFIED="1596453602853" TEXT="2010&#xb144; 1794&#xb9cc; -&gt; 2019&#xb144; 2367&#xb9cc; &#xbcf4;&#xc720;"/>
</node>
<node CREATED="1596442553760" ID="ID_582107425" MODIFIED="1596442557608" TEXT="&#xb3c4;&#xb85c; &#xc2dc;&#xc124; &#xbbf8;&#xbe44;"/>
<node CREATED="1596442557845" ID="ID_1796745996" MODIFIED="1596442563752" TEXT="&#xb9ce;&#xc740; &#xc2e0;&#xd638;&#xb4f1;">
<node CREATED="1596454159741" ID="ID_1451759990" MODIFIED="1596454237608" TEXT="&#xc11c;&#xc6b8;&#xc2dc; &#xc2e0;&#xd638;&#xb4f1; &#xc124;&#xce58; &#xac1c;&#xc218; 2015&#xb144; 18,213 -&gt; 2019&#xb144; 18,472"/>
</node>
<node CREATED="1596442563964" ID="ID_642511790" MODIFIED="1596442567225" TEXT="&#xc6b4;&#xc804;&#xc790; &#xbb34;&#xc9c8;&#xc11c;"/>
</node>
<node CREATED="1596441329094" ID="ID_494319371" MODIFIED="1596441331485" TEXT="&#xb300;&#xcc45;">
<node CREATED="1596442691595" ID="ID_1441779871" MODIFIED="1596443966623" TEXT="&#xad50;&#xd1b5;&#xc2e0;&#xd638;&#xccb4;&#xacc4; &#xac1c;&#xc120;">
<node CREATED="1596444001684" ID="ID_1207821879" MODIFIED="1596444012340" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xc124;&#xce58;&#xb85c; &#xd1b5;&#xd589;&#xc2dc;&#xac04; &#xac10;&#xc18c;"/>
</node>
<node CREATED="1596442706535" ID="ID_1456610137" MODIFIED="1596442724857" TEXT="&#xb300;&#xc911;&#xad50;&#xd1b5; &#xd65c;&#xc131;&#xd654;"/>
<node CREATED="1596442725155" ID="ID_1589205461" MODIFIED="1596442752405" TEXT="&#xbd88;&#xbc95; &#xc8fc;&#xc815;&#xcc28; &#xb2e8;&#xc18d; &#xac15;&#xd654;"/>
</node>
</node>
<node CREATED="1596441239774" ID="ID_576065752" MODIFIED="1596454383125" POSITION="left" TEXT="&#xad50;&#xd1b5;&#xc0ac;&#xace0;">
<icon BUILTIN="info"/>
<node CREATED="1596441347830" ID="ID_1928286918" MODIFIED="1596441350815" TEXT="&#xc815;&#xc758;">
<node CREATED="1596448191739" ID="ID_589698482" MODIFIED="1596448228388">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#44368;&#53685;&#49324;&#44256; &#44368;&#53685;&#49688;&#45800;&#51032; &#50868;&#54665;&#12685;&#54637;&#54665;&#12685;&#50868;&#54637;&#44284; &#44288;&#47144;&#46108; &#49324;&#46988;&#51032; &#49324;&#49345; &#46608;&#45716; &#47932;&#44148;&#51032; &#49552;&#44340;&#47484; &#47568;&#54620;&#45796;.
    </p>
    &#52636;&#52376; :

    <p>
      <a class="b1" href="https://www.law.go.kr/lsInfoP.do?lsiSeq=219229&amp;lsId=&amp;chrClsCd=010202&amp;urlMode=lsInfoP#0000" target="_blank" title="&#xd31d;&#xc5c5;&#xc73c;&#xb85c; &#xc774;&#xb3d9;" style="font-family: Gulim, doutm, tahoma, sans-serif; color: rgb(68, 68, 68); margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; text-decoration: none"><font face="Gulim, doutm, tahoma, sans-serif" color="rgb(68, 68, 68)">- &#44368;&#53685;&#50504;&#51204;&#48277; [&#48277;&#47456; &#51228;17453&#54840;, 2020. 6. 9, &#53440;&#48277;&#44060;&#51221;]</font></a>
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1596441392937" ID="ID_1123439986" MODIFIED="1596523020254" TEXT="&#xd604;&#xd669;">
<node CREATED="1596441847622" ID="ID_182035335" MODIFIED="1596443627781" TEXT="&#xb3c4;&#xb85c; &#xd658;&#xacbd;">
<node CREATED="1596441933166" ID="ID_1141588670" MODIFIED="1596443698636" TEXT="&#xb3c4;&#xb85c; &#xc885;&#xb958;">
<node CREATED="1596442914498" ID="ID_80695287" MODIFIED="1596442917611" TEXT="&#xc77c;&#xbc18; &#xad6d;&#xb3c4;">
<node CREATED="1596449351494" ID="ID_722443761" MODIFIED="1596449392315">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      2015&#45380; &#49324;&#44256; &#44148; &#49688; : 16,880
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1596449551274" ID="ID_1391205903" MODIFIED="1596449718934" TEXT="2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 20,166">
<icon BUILTIN="up"/>
</node>
</node>
<node CREATED="1596442918229" ID="ID_1788021780" MODIFIED="1596442920950" TEXT="&#xc9c0;&#xbc29;&#xb3c4;">
<node CREATED="1596449411740" ID="ID_944032186" MODIFIED="1596449431358" TEXT="2015&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 19,434"/>
<node CREATED="1596449565993" ID="ID_1913733042" MODIFIED="1596449722536" TEXT="2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 16,795">
<icon BUILTIN="down"/>
</node>
</node>
<node CREATED="1596442921210" ID="ID_1721022567" MODIFIED="1596442923809" TEXT="&#xd2b9;&#xbcc4;&#xad11;&#xc5ed;&#xc2dc;&#xb3c4;">
<node CREATED="1596449414536" ID="ID_1254244400" MODIFIED="1596449439071" TEXT="2015&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 91,505"/>
<node CREATED="1596449592590" ID="ID_1847997873" MODIFIED="1596449726728" TEXT="2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 91,795">
<icon BUILTIN="up"/>
</node>
</node>
<node CREATED="1596442924056" ID="ID_1465544356" MODIFIED="1596442924697" TEXT="&#xc2dc;&#xb3c4;">
<node CREATED="1596449417345" ID="ID_825165347" MODIFIED="1596449445986" TEXT="2015&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 75,697"/>
<node CREATED="1596449612607" ID="ID_1241007170" MODIFIED="1596449729468" TEXT="2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 74,953">
<icon BUILTIN="down"/>
</node>
</node>
<node CREATED="1596442924914" ID="ID_868913095" MODIFIED="1596442925614" TEXT="&#xad70;&#xb3c4;">
<node CREATED="1596449420575" ID="ID_1527272481" MODIFIED="1596449525381" TEXT="2015&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 7,946"/>
<node CREATED="1596449632799" ID="ID_635340237" MODIFIED="1596449732160" TEXT="2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 4,223">
<icon BUILTIN="down"/>
</node>
</node>
<node CREATED="1596442925850" ID="ID_1966172847" MODIFIED="1596442927840" TEXT="&#xace0;&#xc18d;&#xad6d;&#xb3c4;">
<node CREATED="1596449423043" ID="ID_444242873" MODIFIED="1596449532117" TEXT="2015&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 4,495"/>
<node CREATED="1596449659139" ID="ID_1775620907" MODIFIED="1596449734464" TEXT="2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218; : 4,223">
<icon BUILTIN="down"/>
</node>
</node>
</node>
<node CREATED="1596266212175" ID="ID_1198226522" MODIFIED="1596450246597" TEXT="&#xb3c4;&#xb85c;&#xd615;&#xd0dc;&#xbcc4; &#xad50;&#xd1b5;&#xc0ac;&#xace0;">
<node CREATED="1596266303685" ID="ID_188366225" MODIFIED="1596266306420" TEXT="&#xb2e8;&#xc77c;&#xb85c;">
<node CREATED="1596266317760" ID="ID_805093325" MODIFIED="1596266321608" TEXT="&#xc0ac;&#xace0;&#xac74;&#xc218;">
<node CREATED="1596266537443" ID="ID_1590075645" MODIFIED="1596266540851" TEXT="104,869"/>
</node>
<node CREATED="1596266321804" ID="ID_1067013847" MODIFIED="1596266323101" TEXT="&#xc0ac;&#xb9dd;&#xc790;&#xc218;">
<node CREATED="1596266542543" ID="ID_1905669598" MODIFIED="1596266547459" TEXT="2,015"/>
</node>
<node CREATED="1596266323342" ID="ID_1697117044" MODIFIED="1596266325800" TEXT="&#xbd80;&#xc0c1;&#xc790;&#xc218;">
<node CREATED="1596266664098" ID="ID_1334184421" MODIFIED="1596266674949" TEXT="154,707"/>
</node>
</node>
<node CREATED="1596266307008" ID="ID_1487345646" MODIFIED="1596266864174" TEXT="&#xad50;&#xcc28;&#xb85c;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1596266328504" ID="ID_43613978" MODIFIED="1596266329805" TEXT="&#xc0ac;&#xace0;&#xac74;&#xc218;">
<node CREATED="1596266849084" ID="ID_997932655" MODIFIED="1596266856771" TEXT="114,425">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1596266330023" ID="ID_1301443221" MODIFIED="1596266331774" TEXT="&#xc0ac;&#xb9dd;&#xc790;&#xc218;">
<node CREATED="1596266720543" ID="ID_115879713" MODIFIED="1596266858729" TEXT="1,205">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
<node CREATED="1596266332000" ID="ID_32682145" MODIFIED="1596266333098" TEXT="&#xbd80;&#xc0c1;&#xc790;&#xc218;">
<node CREATED="1596266725736" ID="ID_403615800" MODIFIED="1596266860877" TEXT="154,707">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
</node>
<node CREATED="1596266309528" ID="ID_1498473570" MODIFIED="1596266312264" TEXT="&#xcca0;&#xae38;&#xac74;&#xb110;&#xbaa9;">
<node CREATED="1596266335165" ID="ID_391016254" MODIFIED="1596266337616" TEXT="&#xc0ac;&#xace0;&#xac74;&#xc218;">
<node CREATED="1596266754311" ID="ID_46269500" MODIFIED="1596266756377" TEXT="8"/>
</node>
<node CREATED="1596266337831" ID="ID_1669087920" MODIFIED="1596266339840" TEXT="&#xc0ac;&#xb9dd;&#xc790;&#xc218;">
<node CREATED="1596266758324" ID="ID_1832095417" MODIFIED="1596266759747" TEXT="2"/>
</node>
<node CREATED="1596266340057" ID="ID_1155886232" MODIFIED="1596266343075" TEXT="&#xbd80;&#xc0c1;&#xc790;&#xc218;">
<node CREATED="1596266761341" ID="ID_1760855178" MODIFIED="1596266762595" TEXT="13"/>
</node>
</node>
<node CREATED="1596266312480" ID="ID_1675000095" MODIFIED="1596266313309" TEXT="&#xae30;&#xd0c0;">
<node CREATED="1596266504096" ID="ID_1184828039" MODIFIED="1596266513883" TEXT="&#xc0ac;&#xace0;&#xac74;&#xc218;">
<node CREATED="1596266764343" ID="ID_1533159871" MODIFIED="1596266798166" TEXT="10,235"/>
</node>
<node CREATED="1596266514106" ID="ID_1595634988" MODIFIED="1596266515533" TEXT="&#xc0ac;&#xb9dd;&#xc790;&#xc218;">
<node CREATED="1596266799873" ID="ID_222293495" MODIFIED="1596266804368" TEXT="126"/>
</node>
<node CREATED="1596266515749" ID="ID_1551992822" MODIFIED="1596266517062" TEXT="&#xbd80;&#xc0c1;&#xc790;&#xc218;">
<node CREATED="1596266806136" ID="ID_1904210773" MODIFIED="1596266810387" TEXT="13,491"/>
</node>
</node>
<node CREATED="1596266313522" ID="ID_1767946896" MODIFIED="1596266314215" TEXT="&#xbd88;&#xba85;">
<node CREATED="1596266518407" ID="ID_894283403" MODIFIED="1596266520635" TEXT="&#xc0ac;&#xace0;&#xac74;&#xc218;">
<node CREATED="1596266812380" ID="ID_59957237" MODIFIED="1596266813680" TEXT="63"/>
</node>
<node CREATED="1596266520850" ID="ID_24568118" MODIFIED="1596266522285" TEXT="&#xc0ac;&#xb9dd;&#xc790;&#xc218;">
<node CREATED="1596266814998" ID="ID_1246469665" MODIFIED="1596266815905" TEXT="1"/>
</node>
<node CREATED="1596266522505" ID="ID_945338363" MODIFIED="1596266524324" TEXT="&#xbd80;&#xc0c1;&#xc790;&#xc218;">
<node CREATED="1596266817799" ID="ID_1131276874" MODIFIED="1596266819313" TEXT="79"/>
</node>
</node>
</node>
</node>
<node CREATED="1596448313461" ID="ID_1529747052" MODIFIED="1596448331896" TEXT="&#xb300;&#xc0c1;&#xbcc4; &#xc0ac;&#xace0;">
<node CREATED="1596448333535" ID="ID_137827053" MODIFIED="1596448335629" TEXT="&#xc5b4;&#xb9b0;&#xc774;">
<node CREATED="1596448418654" ID="ID_1371843251" MODIFIED="1596448700468" TEXT="2015&#xb144; &#xb9cc; 12&#xc138; &#xc774;&#xd558; &#xc0ac;&#xace0; &#xac74;&#xc218;: 5,927,000"/>
<node CREATED="1596448591729" ID="ID_685293850" MODIFIED="1596448704926" TEXT="2019&#xb144; &#xb9cc; 12&#xc138; &#xc774;&#xd558; &#xc0ac;&#xace0; &#xac74;&#xc218;: 5,566,000">
<icon BUILTIN="down"/>
</node>
</node>
<node CREATED="1596448335960" ID="ID_1782664703" MODIFIED="1596448337594" TEXT="&#xb178;&#xc778;">
<node CREATED="1596448626790" ID="ID_1858425040" MODIFIED="1596448649192" TEXT="2015&#xb144; &#xb9cc; 65&#xc138; &#xc774;&#xc0c1; &#xc0ac;&#xace0; &#xac74;&#xc218;: 6,541,000"/>
<node CREATED="1596448651418" ID="ID_460856281" MODIFIED="1596448679178" TEXT="2019&#xb144; &#xb9cc; 65&#xc138; &#xc774;&#xc0c1; &#xc0ac;&#xace0; &#xac74;&#xc218;: 7,685,000">
<icon BUILTIN="up"/>
</node>
<node CREATED="1596448776155" ID="ID_797713302" MODIFIED="1596448818075" TEXT="&#xc5f0;&#xb839;&#xb300;&#xbcc4; &#xbcf4;&#xd589; &#xc0ac;&#xc0c1;&#xc0ac; 57.1%&#xac00; &#xb9cc; 65&#xc138; &#xc774;&#xc0c1; &#xb178;&#xc778;"/>
</node>
</node>
<node CREATED="1596522655916" ID="ID_950346963" MODIFIED="1596522660216" TEXT="&#xbc95;&#xaddc; &#xc704;&#xbc18;&#xbcc4; &#xc0ac;&#xace0;">
<node CREATED="1596522661591" ID="ID_1050545861" MODIFIED="1596522733077" TEXT="&#xc911;&#xc559;&#xc131; &#xce68;&#xbc94;">
<node CREATED="1596522762533" ID="ID_541659083" MODIFIED="1596522838213" TEXT="2016 &#xc0ac;&#xace0; &#xac74; &#xc218; 10,712 -&gt; 2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218;: 9,344"/>
</node>
<node CREATED="1596522733314" ID="ID_784796232" MODIFIED="1596522737621" TEXT="&#xc2e0;&#xd638;&#xc704;&#xbc18;">
<node CREATED="1596522840692" ID="ID_1272939422" MODIFIED="1596522876721" TEXT="2016 &#xc0ac;&#xace0; &#xac74; &#xc218; 24,408 -&gt; 2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218;: 27,921"/>
</node>
<node CREATED="1596522738062" ID="ID_53621299" MODIFIED="1596522741255" TEXT="&#xc548;&#xc804;&#xac70;&#xb9ac; &#xbbf8;&#xd655;&#xbcf4;">
<node CREATED="1596522880979" ID="ID_1699770737" MODIFIED="1596522897143" TEXT="2016 &#xc0ac;&#xace0; &#xac74; &#xc218; 20,660 -&gt; 2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218;: 22,473"/>
</node>
<node CREATED="1596522741504" ID="ID_868081554" MODIFIED="1596522743136" TEXT="&#xacfc;&#xc18d;">
<node CREATED="1596522899040" ID="ID_701132521" MODIFIED="1596522912468" TEXT="2016 &#xc0ac;&#xace0; &#xac74; &#xc218; 663 -&gt; 2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218;: 1,124"/>
</node>
<node CREATED="1596522743688" ID="ID_706751732" MODIFIED="1596522747386" TEXT="&#xc548;&#xc804; &#xc6b4;&#xc804; &#xbd88;&#xc774;&#xd589;">
<node CREATED="1596522913919" ID="ID_628910340" MODIFIED="1596522933347" TEXT="2016 &#xc0ac;&#xace0; &#xac74; &#xc218; 124,399 -&gt; 2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218;: 126,006"/>
</node>
<node CREATED="1596522747612" ID="ID_1494637600" MODIFIED="1596522753960" TEXT="&#xad50;&#xcc28;&#xb85c; &#xc6b4;&#xd589; &#xbc29;&#xbc95; &#xc704;&#xbc18;">
<node CREATED="1596522934928" ID="ID_1353083246" MODIFIED="1596522949012" TEXT="2016 &#xc0ac;&#xace0; &#xac74; &#xc218; 14,602 -&gt; 2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218;: 15,372"/>
</node>
<node CREATED="1596522754186" ID="ID_1806467086" MODIFIED="1596522759629" TEXT="&#xbcf4;&#xd589;&#xc790; &#xbcf4;&#xd638; &#xc758;&#xbb34; &#xc704;&#xbc18;">
<node CREATED="1596522950826" ID="ID_943779445" MODIFIED="1596522964869" TEXT="2016 &#xc0ac;&#xace0; &#xac74; &#xc218; 7,808 -&gt; 2019&#xb144; &#xc0ac;&#xace0; &#xac74; &#xc218;: 8,055"/>
</node>
</node>
<node CREATED="1596449042802" ID="ID_265988735" MODIFIED="1596449045928" TEXT="&#xc138;&#xacc4;&#xc801; &#xd604;&#xd669;">
<node CREATED="1596449046984" ID="ID_1608685974" MODIFIED="1596449108963" TEXT="(2017)&#xc778;&#xad6c; 10&#xb9cc;&#xba85; &#xb2f9; &#xad50;&#xd1b5;&#xc0ac;&#xace0; &#xac74; &#xc218; 421.2&#xb85c; OECD 3&#xc704;">
<icon BUILTIN="closed"/>
<node CREATED="1596449116533" ID="ID_673702716" MODIFIED="1596449130693" TEXT="OECD &#xd3c9;&#xade0; : 299.4&#xac74;"/>
</node>
<node CREATED="1596523198155" ID="ID_1953063670" MODIFIED="1596523284495" TEXT="(2017)&#xc790;&#xb3d9;&#xcc28; 1&#xb9cc;&#xb300; &#xb2f9; &#xad50;&#xd1b5;&#xc0ac;&#xace0; 80.2&#xac74;&#xc73c;&#xb85c; OECD 2&#xc704;">
<icon BUILTIN="closed"/>
<node CREATED="1596523241045" ID="ID_1874340238" MODIFIED="1596523266771" TEXT="OECD &#xd3c9;&#xade0;: 36.4&#xac74;"/>
</node>
<node CREATED="1596523456516" ID="ID_1672547061" MODIFIED="1596523491271" TEXT="(2014) &#xcd9c;&#xadfc; &#xc18c;&#xc694;&#xc2dc;&#xac04; 58&#xbd84;&#xc73c;&#xb85c; OECD 1&#xc704;">
<icon BUILTIN="closed"/>
<node CREATED="1596523493041" ID="ID_924556213" MODIFIED="1596523507798" TEXT="OECD &#xd3c9;&#xade0;: 28&#xbd84;"/>
</node>
</node>
</node>
<node CREATED="1596442048018" ID="ID_1767268619" MODIFIED="1596442050237" TEXT="&#xb300;&#xcc45;">
<node CREATED="1596443809007" ID="ID_762145346" MODIFIED="1596444065022" TEXT="&#xb3c4;&#xb85c; &#xad6c;&#xc870; &#xac1c;&#xc120;">
<node CREATED="1596444110883" ID="ID_1676283991" MODIFIED="1596444889280" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xc124;&#xce58;">
<icon BUILTIN="messagebox_warning"/>
<node BACKGROUND_COLOR="#ffffff" COLOR="#ff0033" CREATED="1596256725569" FOLDED="true" ID="ID_162332540" MODIFIED="1596524227096" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;">
<font BOLD="true" NAME="SansSerif" SIZE="15"/>
<icon BUILTIN="idea"/>
<node CREATED="1596256793872" ID="ID_1960596563" MODIFIED="1596258893979" TEXT="&#xc815;&#xc758;">
<node CREATED="1596256802270" ID="ID_648324740" MODIFIED="1596258915084" TEXT="&#xd3c9;&#xba74;&#xad50;&#xcc28;&#xb85c;&#xc758; &#xc77c;&#xc885;&#xc774;&#xba70;, &#xad50;&#xcc28;&#xb85c; &#xc911;&#xc559;&#xc5d0; &#xc6d0;&#xd615;&#xad50;&#xd1b5;&#xc12c;&#xc744; &#xb450;&#xace0; &#xad50;&#xcc28;&#xb85c;&#xb97c; &#xd1b5;&#xacfc;&#xd558;&#xb294; &#xc790;&#xb3d9;&#xcc28;&#xac00; &#xc6d0;&#xd615;&#xad50;&#xd1b5;&#xc12c;&#xc744; &#xc6b0;&#xd68c;&#xd558;&#xb3c4;&#xb85d; &#xd558;&#xb294; &#xad50;&#xcc28;&#xb85c; &#xd615;&#xc2dd;&#xc744; &#xb9d0;&#xd55c;&#xb2e4;.&#xa;&#xa;&#xcd9c;&#xcc98;: &#xb3c4;&#xc2dc;&#xc9c0;&#xc5ed; &#xc124;&#xacc4; &#xc9c0;&#xae08;[&#xad6d;&#xd1a0;&#xad50;&#xd1b5;&#xbd80; &#xd6c8;&#xb839; &#xc81c; 1266&#xd638;, 2019.12.24 &#xc81c;&#xc815;]">
<node CREATED="1596257048257" ID="ID_12189040" MODIFIED="1596257055252" TEXT="&#xd3c9;&#xba74; &#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596257094698" ID="ID_1968975358" MODIFIED="1596257666345" TEXT="&#xb3c4;&#xb85c;&#xc640; &#xb3c4;&#xb85c; &#xb610;&#xb294; &#xb3c4;&#xb85c;&#xc640; &#xcca0;&#xb85c;&#xac00; &#xc11c;&#xb85c; &#xad50;&#xcc28; &#xacf5;&#xac04; &#xbc0f; &#xadf8; &#xb0b4;&#xbd80;&#xc758; &#xad50;&#xd1b5;&#xc2dc;&#xc124;&#xbb3c;&#xc744; &#xb9d0;&#xd55c;&#xb2e4;.&#xa;&#xcd9c;&#xcc98; : - &#xb3c4;&#xc2dc;&#xc9c0;&#xc5ed;&#xb3c4;&#xb85c; &#xc124;&#xacc4; &#xc9c0;&#xce68; [&#xad6d;&#xd1a0;&#xad50;&#xd1b5;&#xbd80;&#xd6c8;&#xb839; &#xc81c;1266&#xd638;, 2019. 12. 24, &#xc81c;&#xc815;] &#xc81c;3&#xc870; (&#xc815;&#xc758;)"/>
</node>
<node CREATED="1596257076652" ID="ID_954039491" MODIFIED="1596257078313" TEXT="&#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596257286549" ID="ID_787108757" MODIFIED="1596257677855" TEXT="&#xc138;&#xac08;&#xb798;&#xad50;&#xcc28;&#xb85c;, &#xb124;&#xac08;&#xb798;&#xad50;&#xcc28;&#xb85c;, &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;, &#xc785;&#xccb4;&#xad50;&#xcc28;&#xb85c; &#xb4f1; &#xb458; &#xc774;&#xc0c1;&#xc758; &#xb3c4;&#xb85c;&#xac00; &#xad50;&#xcc28;&#xb418;&#xac70;&#xb098; &#xc811;&#xc18d;&#xb418;&#xb294; &#xacf5;&#xac04;&#xc744; &#xb9d0;&#xd55c;&#xb2e4;. &#xa;&#xcd9c;&#xcc98; : - &#xb3c4;&#xb85c;&#xc640; &#xb2e4;&#xb978; &#xc2dc;&#xc124;&#xc758; &#xc5f0;&#xacb0;&#xc5d0; &#xad00;&#xd55c; &#xaddc;&#xce59; [&#xad6d;&#xd1a0;&#xad50;&#xd1b5;&#xbd80;&#xb839; &#xc81c;706&#xd638;, 2020. 3. 6, &#xd0c0;&#xbc95;&#xac1c;&#xc815;]">
<node CREATED="1596258535879" ID="ID_316809406" MODIFIED="1596258538533" TEXT="&#xc785;&#xccb4; &#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596258539546" ID="ID_271069950" MODIFIED="1596258612154" TEXT="&#xc785;&#xccb4;&#xc801; &#xad50;&#xcc28;&#xd615;&#xc2dd;&#xc73c;&#xb85c; &#xad50;&#xcc28;&#xd558;&#xb294; &#xb3c4;&#xb85c;&#xc640; &#xb3c4;&#xb85c;, &#xb3c4;&#xb85c;&#xc640; &#xcca0;&#xb3c4;&#xb97c; &#xb9d0;&#xd558;&#xb294;&#xb370; &#xb3d9;&#xc77c;&#xd55c; &#xd3c9;&#xba74;&#xb3c4;&#xb85c;&#xc5d0;&#xc11c; &#xad50;&#xcc28;&#xd558;&#xb294; &#xac83;&#xc774; &#xc544;&#xb2c8;&#xb77c;, &#xb192;&#xc774;&#xb97c; &#xb2ec;&#xb9ac;&#xd574;&#xc11c; &#xad50;&#xcc28;&#xd55c;&#xb2e4;. &#xd6a1;&#xb2e8; &#xc721;&#xad50;&#xb7;&#xd6a1;&#xb2e8; &#xc9c0;&#xd558;&#xb3c4;&#xc5d0;&#xc11c;&#xbd80;&#xd130; &#xace0;&#xc18d;&#xb3c4;&#xb85c;&#xc758; &#xc778;&#xd130;&#xccb4;&#xc778;&#xc9c0;&#xae4c;&#xc9c0; &#xc5ec;&#xb7ec; &#xac00;&#xc9c0;&#xac00; &#xc788;&#xc73c;&#xba70; &#xb3c4;&#xb85c;&#xc640; &#xcca0;&#xb3c4;&#xac00; &#xad50;&#xcc28;&#xd558;&#xb294; &#xc721;&#xad50;&#xb098; &#xac00;&#xb4dc;(guard)&#xcc98;&#xb7fc; &#xc11c;&#xb85c;&#xc758; &#xad50;&#xd1b5;&#xc774; &#xc811;&#xc18d;&#xd558;&#xc9c0; &#xc54a;&#xb294; &#xac83;&#xacfc; &#xc778;&#xd130;&#xccb4;&#xc778;&#xc9c0;&#xc640; &#xac19;&#xc774; &#xc5f0;&#xacb0;&#xb85c;&#xc5d0; &#xc758;&#xd574; &#xc11c;&#xb85c; &#xc811;&#xc18d;&#xb418;&#xc5b4; &#xc788;&#xb294; &#xac83;&#xc73c;&#xb85c; &#xad6c;&#xbcc4;&#xb41c;&#xb2e4;. [&#xb124;&#xc774;&#xbc84; &#xc9c0;&#xc2dd;&#xbc31;&#xacfc;] &#xc785;&#xccb4;&#xad50;&#xcc28;&#xb85c; [interchange, &#x7acb;&#x9ad4;&#x4ea4;&#x53c9;&#x8def;] (&#xb450;&#xc0b0;&#xbc31;&#xacfc;)"/>
</node>
<node CREATED="1596258716139" ID="ID_857141004" MODIFIED="1596258720192" TEXT="&#xc138;&#xac08;&#xb798;&#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596258800428" ID="ID_813200171" MODIFIED="1596258808113" TEXT="&#xad50;&#xcc28;&#xb85c;&#xc758; &#xac08;&#xb798;&#xac00; 3&#xac1c;&#xc778; &#xad50;&#xcc28;&#xb85c;&#xb97c; &#xb9d0;&#xd558;&#xace0;, &#xad50;&#xcc28;&#xac01;&#xc5d0; &#xb530;&#xb77c; Y&#xd615;&#xad50;&#xcc28;&#xb85c;&#xc640; T&#xd615;&#xad50;&#xcc28;&#xb85c;&#xb85c; &#xb098;&#xb208;&#xb2e4; [&#xcd9c;&#xcc98;] &#xad50;&#xd1b5;&#xc6a9;&#xc5b4; 305, &#xc138;&#xac08;&#xb798;&#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596258814518" ID="ID_1897661590" MODIFIED="1596258826817" TEXT="Y&#xd615;&#xad50;&#xcc28;&#xb85c; : &#xad50;&#xcc28;&#xac01; 75&#x3002;&#xc774;&#xd558;, 105&#x3002; &#xc774;&#xc0c1;&#xc815;&#xb3c4; [&#xcd9c;&#xcc98;] &#xad50;&#xd1b5;&#xc6a9;&#xc5b4; 305, &#xc138;&#xac08;&#xb798;&#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258829296" ID="ID_1821004220" MODIFIED="1596258839038" TEXT="T&#xd615;&#xad50;&#xcc28;&#xb85c; : &#xad50;&#xcc28;&#xac01; 75&#x3002; &#x223c; 105&#x3002;&#xc774;&#xb0b4;&#xc758; &#xc815;&#xb3c4; [&#xcd9c;&#xcc98;] &#xad50;&#xd1b5;&#xc6a9;&#xc5b4; 305, &#xc138;&#xac08;&#xb798;&#xad50;&#xcc28;&#xb85c;"/>
</node>
</node>
<node CREATED="1596257737171" ID="ID_1284314190" MODIFIED="1596258748157" TEXT="&#xb85c;&#xd130;&#xb9ac;">
<node CREATED="1596257744336" ID="ID_1886194714" MODIFIED="1596257813995">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#44368;&#53685;&#51060; &#48373;&#51105;&#54620; &#45348;&#44144;&#47532; &#44057;&#51008; &#44275;&#50640; &#44368;&#53685;&#51221;&#47532;&#47484; &#50948;&#54616;&#50668; &#50896;&#54805;&#51004;&#47196; &#47564;&#46308;&#50612; &#45459;&#51008; &#44368;&#52264;&#47196;.
    </p>
    <p>
      &#52636;&#52376;: &#54364;&#51456;&#44397;&#50612;&#45824;&#49324;&#51204;&#160;
    </p>
  </body>
</html></richcontent>
<node CREATED="1596257821419" ID="ID_472203483" MODIFIED="1596257933510" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;&#xc640; &#xb85c;&#xd130;&#xb9ac;&#xc758; &#xcc28;&#xc774;&#xc810;">
<node CREATED="1596257830488" ID="ID_647532636" MODIFIED="1596257966394" TEXT="&#xc9c4;&#xc785;&#xd1b5;&#xc81c;">
<node CREATED="1596258009587" ID="ID_991151129" MODIFIED="1596258033667" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xc9c4;&#xc785; &#xc9c0;&#xc810;&#xc5d0; &#xc591;&#xbcf4;&#xd45c;&#xc2dc; - &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258034917" ID="ID_317197283" MODIFIED="1596258077687" TEXT="&#xc815;&#xc9c0;&#xd45c;&#xc9c0;&#xd310;, &#xc2e0;&#xd638;&#xb4f1; &#xd639;&#xc740; &#xc9c4;&#xc785; &#xcc28;&#xb7c9;&#xc5d0; &#xc6b0;&#xc120;&#xad8c; &#xbd80;&#xc5ec; - &#xb85c;&#xd130;&#xb9ac;"/>
</node>
<node CREATED="1596257969009" ID="ID_995070489" MODIFIED="1596257971560" TEXT="&#xc6b4;&#xc601;&#xd2b9;&#xc131;">
<node CREATED="1596258079575" ID="ID_1721526224" MODIFIED="1596258140766" TEXT=" &#xd68c;&#xc804;&#xcc28;&#xb85c; &#xb0b4; &#xcc28;&#xb7c9;&#xc740; &#xc9c4;&#xc785;&#xcc28;&#xb7c9;&#xc5d0; &#xb300;&#xd574; &#xc6b0;&#xc120;&#xad8c; - &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258114927" ID="ID_1119818669" MODIFIED="1596258136441" TEXT="&#xc0c1;&#xcda9; &#xc774;&#xb3d9;&#xb958; &#xd574;&#xacb0;&#xc5d0; &#xc5c7;&#xac08;&#xb9bc; &#xc9c0;&#xc5ed; &#xd5c8;&#xc6a9; - &#xb85c;&#xd130;&#xb9ac;"/>
</node>
<node CREATED="1596257976116" ID="ID_180790222" MODIFIED="1596257982381" TEXT="&#xc774;&#xb3d9;&#xacbd;&#xb85c; &#xbcc0;&#xd654;">
<node CREATED="1596258143109" ID="ID_1326753370" MODIFIED="1596258172535" TEXT="&#xd68c;&#xc804;&#xcc28;&#xb85c;&#xc5d0;&#xc11c; &#xc800;&#xc18d; &#xc6b4;&#xd589;&#xd558;&#xb3c4;&#xb85d; &#xc774;&#xb3d9;&#xacbd;&#xb85c; &#xbcc0;&#xd654; &#xd65c;&#xc6a9;  - &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258172914" ID="ID_1808806968" MODIFIED="1596258207031" TEXT="&#xb300;&#xaddc;&#xbaa8; &#xc11c;&#xd074;&#xc5d0;&#xc11c;&#xb294; &#xace0;&#xc18d; &#xc774;&#xb3d9;&#xb958;&#xb97c; &#xc704;&#xd574; &#xc9c1;&#xc9c4; &#xd5c8;&#xc6a9; - &#xb85c;&#xd130;&#xb9ac;"/>
</node>
<node CREATED="1596257984939" ID="ID_436062042" MODIFIED="1596257986178" TEXT="&#xc8fc;&#xcc28;">
<node CREATED="1596258215469" ID="ID_959521881" MODIFIED="1596258323908" TEXT="&#xd68c;&#xc804;&#xcc28;&#xb85c; &#xb0b4; &#xc8fc;&#xcc28; &#xae08;&#xc9c0; - &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258223140" ID="ID_322488400" MODIFIED="1596258350552" TEXT="&#xb300;&#xaddc;&#xbaa8; &#xc11c;&#xd074;&#xc5d0;&#xc11c;&#xb294; &#xd68c;&#xc804;&#xcc28;&#xb85c; &#xb0b4; &#xc8fc;&#xcc28; &#xd5c8;&#xc6a9; - &#xb85c;&#xd130;&#xb9ac;"/>
</node>
<node CREATED="1596257986543" ID="ID_997709746" MODIFIED="1596257992172" TEXT="&#xbcf4;&#xd589;&#xd6a1;&#xb2e8;">
<node CREATED="1596258245518" ID="ID_1498924820" MODIFIED="1596258340856" TEXT="&#xc911;&#xc559; &#xad50;&#xd1b5;&#xc12c; &#xb0b4; &#xbcf4;&#xd589;&#xd65c;&#xb3d9; &#xae08;&#xc9c0; - &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258280958" ID="ID_1463072685" MODIFIED="1596258346466" TEXT="&#xb300;&#xaddc;&#xbaa8; &#xc11c;&#xd074;&#xc5d0;&#xc11c;&#xb294; &#xc911;&#xc559; &#xad50;&#xd1b5;&#xc12c;&#xc758; &#xbcf4;&#xd589;&#xc790; &#xd6a1;&#xb2e8; &#xb4f1;&#xc758; &#xd65c;&#xb3d9; &#xd5c8;&#xc6a9; - &#xb85c;&#xd130;&#xb9ac;"/>
</node>
<node CREATED="1596257995936" ID="ID_1257245253" MODIFIED="1596258002359" TEXT="&#xd68c;&#xc804;&#xc774;&#xb3d9;">
<node CREATED="1596258354081" ID="ID_1570008031" MODIFIED="1596258382949" TEXT="&#xbaa8;&#xb4e0; &#xcc28;&#xb7c9;&#xc740; &#xc911;&#xc559; &#xad50;&#xd1b5;&#xc12c;&#xc744; &#xbc18;&#xc2dc;&#xacc4; &#xbc29;&#xd5a5;&#xc73c;&#xb85c; &#xd68c;&#xc804; - &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258383181" ID="ID_1016271702" MODIFIED="1596258413830" TEXT="&#xc18c;&#xaddc;&#xbaa8; &#xc11c;&#xd074;&#xc758; &#xacbd;&#xc6b0; &#xc88c;&#xd68c;&#xc804; &#xcc28;&#xb7c9;&#xc740; &#xc911;&#xc559; &#xad50;&#xd1b5;&#xc12c;&#xc758; &#xc88c;&#xce21;&#xd1b5;&#xd589; &#xd5c8;&#xc6a9; &#xac00;&#xb2a5; - &#xb85c;&#xd130;&#xb9ac;"/>
</node>
<node CREATED="1596258002597" ID="ID_1488047431" MODIFIED="1596258006978" TEXT="&#xbd84;&#xb9ac;&#xad50;&#xd1b5;&#xc12c;">
<node CREATED="1596258415492" ID="ID_233417003" MODIFIED="1596258423444" TEXT=" &#xd544;&#xc218;&#xc801; - &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258423676" ID="ID_1656293334" MODIFIED="1596258430452" TEXT="&#xc120;&#xd0dd;&#xc801; - &#xb85c;&#xd130;&#xb9ac;"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1596257055790" ID="ID_86214778" MODIFIED="1596257434536" TEXT="&#xad50;&#xd1b5;&#xc12c;">
<node CREATED="1596257407519" ID="ID_884318093" MODIFIED="1596257428709" TEXT="&#xcc28;&#xb7c9;&#xc758; &#xc548;&#xc804;&#xd558;&#xace0; &#xc6d0;&#xd65c;&#xd55c; &#xad50;&#xd1b5;&#xcc98;&#xb9ac;&#xb098; &#xbcf4;&#xd589;&#xc790; &#xb3c4;&#xb85c;&#xd6a1;&#xb2e8;&#xc758; &#xc548;&#xc804;&#xc744; &#xd655;&#xbcf4;&#xd558;&#xae30; &#xc704;&#xd558;&#xc5ec; &#xad50;&#xcc28;&#xb85c; &#xb610;&#xb294; &#xcc28;&#xb3c4;&#xc758; &#xbd84;&#xae30;&#xc810; &#xb4f1;&#xc5d0; &#xc124;&#xce58;&#xd558;&#xb294; &#xc12c;&#xbaa8;&#xc591;&#xc758; &#xc2dc;&#xc124;&#xc744; &#xb9d0;&#xd55c;&#xb2e4;.&#xa;&#xa;&#x300c;&#xb3c4;&#xb85c;&#xc758; &#xad6c;&#xc870; &#xb7; &#xc2dc;&#xc124; &#xae30;&#xc900;&#xc5d0; &#xad00;&#xd55c; &#xaddc;&#xce59;&#x300d; &#xc81c;2&#xc870;"/>
</node>
</node>
<node CREATED="1596258897983" ID="ID_1993002726" MODIFIED="1596258912710" TEXT="ROUNDABOUTS">
<node CREATED="1596259209609" ID="ID_7620181" MODIFIED="1596259499910" TEXT="a circuitous or indirect road, method, etc."/>
</node>
</node>
<node CREATED="1596256796617" ID="ID_46183863" MODIFIED="1596450407688" TEXT="&#xd544;&#xc694;&#xc131;">
<icon BUILTIN="button_ok"/>
<node CREATED="1596258939771" ID="ID_422629181" MODIFIED="1596259007595" TEXT="&#xad50;&#xd1b5; &#xccb4;&#xc99d; &#xd574;&#xc18c;">
<node CREATED="1596259054228" ID="ID_343500259" MODIFIED="1596259088557">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#49888;&#54840;&#44592;&#47484; &#49444;&#52824;&#54616;&#51648; &#50506;&#50500; &#49888;&#54840;&#50640; &#46384;&#47480; &#51221;&#51648;&#49884;&#44036;&#51060; &#44048;&#49548;&#54616;&#50668; &#44368;&#52264;&#47196; &#44368;&#53685;&#47049; &#51613;&#44032;&#50640;&#46020; &#44557;&#51221;&#51201; &#54217;&#44032;
    </p>
    <p>
      &#52636;&#52376;: &#46020;&#47196;&#44368;&#53685;&#44277;&#45800;
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_343500259" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_22741822" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_343500259" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_22741822" SOURCE="ID_343500259" STARTARROW="None" STARTINCLINATION="0;0;"/>
<node CREATED="1596260132608" ID="ID_1507183433" MODIFIED="1596260143312" TEXT="&#xc9c0;&#xc815;&#xccb4; &#xac10;&#xc18c;">
<node CREATED="1596260144544" ID="ID_879100453" MODIFIED="1596260164035" TEXT="&#xbd88;&#xd544;&#xc694;&#xd55c; &#xc2e0;&#xd638; &#xb300;&#xae30;&#xc2dc;&#xac04;&#xc744; &#xac10;&#xc18c; &#xc2dc;&#xcf1c; &#xc9c0;&#xccb4;&#xb97c; &#xd06c;&#xac8c; &#xac10;&#xc18c;&#xc2dc;&#xd0b4;">
<node CREATED="1596260189061" ID="ID_35126176" MODIFIED="1596260217986" TEXT=" &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;&#xb294; &#xc77c; &#xad50;&#xd1b5;&#xb7c9;&#xc774; 10,000(&#xb300;/&#xc77c;) &#xc774;&#xd558;&#xc778; &#xc9c0;&#xc810;&#xc5d0;&#xc11c; &#xc9c0;&#xccb4;&#xac10;&#xc18c;&#xc758; &#xd6a8;&#xacfc;&#xac00; &#xb192;&#xc740; &#xac83;&#xc73c;&#xb85c; &#xbd84;&#xc11d;&#xb428;(2010&#xb144; &#xd68c;&#xc804;&#xad50;&#xcc28; &#xb85c; &#xd6a8;&#xacfc;&#xbd84;&#xc11d;- &#xad50;&#xd1b5;&#xc6b4;&#xc601; &#xce21;&#xba74; &#xbd84;&#xc11d;&#xacb0;&#xacfc;) "/>
</node>
</node>
</node>
</node>
<node CREATED="1596258977477" ID="ID_179719685" MODIFIED="1596258984071" TEXT="&#xad50;&#xd1b5; &#xc0ac;&#xace0; &#xac10;&#xc18c;">
<node CREATED="1596259034016" ID="ID_727589804" MODIFIED="1596259049347" TEXT="&#xd504;&#xb791;&#xc2a4;, &#xb3c5;&#xc77c;, &#xc601;&#xad6d;, &#xbbf8;&#xad6d; &#xb4f1; &#xb9ce;&#xc740; &#xad6d;&#xac00;&#xb4e4;&#xc774; &#xc124;&#xce58;&#xd55c; ROUNDABOUTS(&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;)&#xc73c;&#xb85c; &#xc778;&#xd574; &#xc0ac;&#xace0; &#xac74;&#xc218; &#xbc0f; &#xc0ac;&#xb9dd;&#xc790;&#xb97c; &#xd68d;&#xae30;&#xc801;&#xc73c;&#xb85c; &#xac10;&#xc18c;&#xc2dc;&#xcf1c; &#xc548;&#xc804;&#xd55c; &#xc2dc;&#xc124;&#xbb3c;&#xb85c; &#xd3c9;&#xac00;&#xa;&#xcd9c;&#xcc98; : &#xb3c4;&#xb85c;&#xad50;&#xd1b5;&#xacf5;&#xb2e8;">
<node CREATED="1596260231285" ID="ID_234684472" MODIFIED="1596260250961" TEXT="&#xcc28;&#xb7c9; &#xac04;&#xc758; &#xc0c1;&#xcda9;&#xd69f;&#xc218;&#xb97c; &#xc904;&#xc5ec;&#xc8fc;&#xae30; &#xb54c;&#xbb38;&#xc5d0; &#xad50;&#xd1b5;&#xc0ac;&#xace0; &#xac10;&#xc18c;&#xc5d0; &#xd6a8;&#xacfc;&#xac00; &#xb192;&#xc74c;">
<node CREATED="1596260353990" ID="ID_1500350279" MODIFIED="1596260374675" TEXT="&#xcc28;&#xb7c9;&#xac04;&#xc758; &#xc0c1;&#xcda9;&#xc740; &#xbcf4;&#xd1b5; &#xb300;&#xbd80;&#xbd84; &#xc2e0;&#xd638;&#xac00; &#xc5c6;&#xb294; &#xad50;&#xcc28;&#xb85c;&#xc5d0;&#xc11c; &#xb9ce;&#xc774; &#xbc1c;&#xc0dd;"/>
<node CREATED="1596260374896" ID="ID_265723889" MODIFIED="1596260387677" TEXT="&#xc77c;&#xbc18;&#xc801;&#xc73c;&#xb85c; &#xbe44;&#xc2e0;&#xd638; &#xad50;&#xcc28;&#xb85c;&#xb294; &#xad50;&#xd1b5;&#xb7c9;&#xc774; &#xc801;&#xac70;&#xb098; &#xbcf4;&#xd589;&#xb7c9;&#xc774; &#xb9ce;&#xc740; &#xc0dd;&#xd65c;&#xad8c; &#xb3c4;&#xb85c;&#xc5d0;&#xc11c; &#xc6b4;&#xc601;&#xb428;"/>
<node CREATED="1596261096485" ID="ID_1672159947" MODIFIED="1596261135828" TEXT="&#xb300;&#xad6c;&#xc2dc; &#xbd81;&#xad6c; &#xb3d9;&#xcc9c;&#xb3d9; &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xad50;&#xd1b5;&#xc0ac;&#xace0; &#xbd84;&#xc11d; &#xacb0;&#xacfc; ">
<node CREATED="1596261137310" ID="ID_1236681239" MODIFIED="1596261150807" TEXT="&#xad50;&#xd1b5;&#xc0ac;&#xace0; &#xbc1c;&#xc0dd;&#xac74;&#xc218; 80% &#xac10;&#xc18c;"/>
<node CREATED="1596261151312" ID="ID_1001454752" MODIFIED="1596261157263" TEXT="&#xbd80;&#xc0c1;&#xc790; &#xc218; 66.7% &#xac10;&#xc18c;"/>
<node CREATED="1596261189809" ID="ID_1460323899" MODIFIED="1596261213114" TEXT="&#xcd9c;&#xcc98;: &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xc124;&#xce58;&#xc5d0; &#xb530;&#xb978; &#xad50;&#xd1b5;&#xc0ac;&#xace0; &#xd6a8;&#xacfc;&#xbd84;&#xc11d;(&#xc800;: &#xad8c;&#xc624;&#xacbd;)"/>
</node>
<node CREATED="1596262244212" ID="ID_1546640556" MODIFIED="1596262257743" TEXT="&#xc0c1;&#xcda9; &#xd69f;&#xc218;&#xc758; &#xac10;&#xc18c;">
<node CREATED="1596262354043" ID="ID_384003360" MODIFIED="1596262360388" TEXT="&#xc790;&#xb3d9;&#xcc28; &#xac04; &#xc0c1;&#xcda9;&#xd69f;&#xc218;">
<node CREATED="1596262361240" ID="ID_1769543383" MODIFIED="1596262368036" TEXT="&#xd3c9;&#xba74;&#xad50;&#xcc28;&#xb85c; 32&#xd68c;"/>
<node CREATED="1596262368676" ID="ID_1345641101" MODIFIED="1596262373370" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; 8&#xd68c;"/>
</node>
<node CREATED="1596262376952" ID="ID_1015426368" MODIFIED="1596262387482" TEXT="&#xad50;&#xcc28;&#xc0c1;&#xcda9;&#xd69f;&#xc218;">
<node CREATED="1596262388528" ID="ID_126190992" MODIFIED="1596262394017" TEXT="&#xd3c9;&#xba74;&#xad50;&#xcc28;&#xb85c; 16&#xd68c;"/>
<node CREATED="1596262394371" ID="ID_93101197" MODIFIED="1596262404853" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; 0&#xd68c;"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1596260557165" ID="ID_1088862295" MODIFIED="1596262501029" TEXT="&#xc720;&#xd615;">
<node CREATED="1596262510113" ID="ID_1058955352" MODIFIED="1596262513032" TEXT="&#xae30;&#xbcf8;&#xc720;&#xd615;">
<node CREATED="1596260561369" ID="ID_98583733" MODIFIED="1596260565021" TEXT="&#xc18c;&#xd615; &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596260601924" ID="ID_350348250" MODIFIED="1596260612272" TEXT="&#xc124;&#xacc4;&#xae30;&#xc900; &#xc790;&#xb3d9;&#xcc28;: &#xc18c;&#xd615;&#xc790;&#xb3d9;&#xcc28;"/>
<node CREATED="1596260630376" ID="ID_1560578788" MODIFIED="1596260653951" TEXT="&#xd3c9;&#xade0; &#xc8fc;&#xd589;&#xc18d;&#xb3c4; 50km/h &#xbbf8;&#xb9cc;&#xc778; &#xb3c4;&#xc2dc;&#xc9c0;&#xc5ed;&#xc5d0;&#xc11c; &#xcd5c;&#xc18c;&#xd55c;&#xc758; &#xc124;&#xacc4;&#xc81c;&#xc6d0;&#xc73c;&#xb85c; &#xcca0;&#xc2dc;&#xd560; &#xc218; &#xc788;&#xb2e4;."/>
<node CREATED="1596260694263" ID="ID_908927003" MODIFIED="1596260730685" TEXT="&#xc911;&#xc559;&#xad50;&#xd1b5;&#xc12c; &#xb178;&#xba74;&#xd45c;&#xc2dc; &#xcc98;&#xb9ac; &#xc9c0;&#xc591;"/>
</node>
<node CREATED="1596260588185" ID="ID_1091918105" MODIFIED="1596260789839" TEXT="1,2&#xcc28;&#xb85c;&#xd615; &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596260733604" ID="ID_475337305" MODIFIED="1596260746603" TEXT="&#xc124;&#xacc4;&#xae30;&#xc900; &#xc790;&#xb3d9;&#xcc28;: &#xb300;&#xd615;&#xc790;&#xb3d9;&#xcc28; &#xb610;&#xb294; &#xc138;&#xbbf8;&#xd2b8;&#xb808;&#xc77c;&#xb7ec;"/>
<node CREATED="1596260749196" ID="ID_691178532" MODIFIED="1596260771247" TEXT="&#xc911;&#xc559;&#xad50;&#xd1b5;&#xc12c;&#xc740; &#xd6a1;&#xb2e8;&#xd560; &#xc218; &#xc5c6;&#xb2e4;"/>
<node CREATED="1596260842648" ID="ID_1416529369" MODIFIED="1596260844015" TEXT="&#xad6c;&#xbd84;">
<node CREATED="1596260845135" ID="ID_1195660416" MODIFIED="1596260865867" TEXT="&#xd68c;&#xc804;&#xcc28;&#xb85c;&#xc758; &#xc218; 1&#xac1c; &#xc77c; &#xb54c;">
<node CREATED="1596260877965" ID="ID_526290737" MODIFIED="1596260883051" TEXT="1&#xcc28;&#xb85c;&#xd615; &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;"/>
</node>
<node CREATED="1596260866921" ID="ID_772560081" MODIFIED="1596260876719" TEXT="&#xd68c;&#xc804;&#xcc28;&#xb85c;&#xc758; &#xc218; 2&#xac1c;&#xc77c; &#xb54c;">
<node CREATED="1596260884878" ID="ID_1415645106" MODIFIED="1596260887968" TEXT="2&#xcc28;&#xb85c;&#xd615; &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;"/>
</node>
</node>
</node>
<node CREATED="1596262542939" ID="ID_902840286" MODIFIED="1596262554054" TEXT="&#xae30;&#xbcf8; &#xc720;&#xd615;&#xc774; &#xc6d0;&#xce59;">
<icon BUILTIN="info"/>
</node>
</node>
<node CREATED="1596262520616" ID="ID_1240926907" MODIFIED="1596262525148" TEXT="&#xd2b9;&#xc218;&#xc720;&#xd615;">
<node CREATED="1596262526476" ID="ID_320667702" MODIFIED="1596262566213" TEXT="&#xd3c9;&#xba85;&#xd604; &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596262571762" ID="ID_148224522" MODIFIED="1596262586620" TEXT="&#xc9c1;&#xacb0;&#xd615;">
<node CREATED="1596264054093" ID="ID_1010372146" MODIFIED="1596264057690" TEXT="&#xad50;&#xd1b5;&#xc12c; &#xd55c;&#xac1c;"/>
</node>
<node CREATED="1596262586860" ID="ID_271706889" MODIFIED="1596262588057" TEXT="&#xc30d;&#xad6c;&#xd615;">
<node CREATED="1596264060309" ID="ID_1208105763" MODIFIED="1596264062978" TEXT="&#xad50;&#xd1b5;&#xc12c; 2&#xac1c;"/>
</node>
<node CREATED="1596263776547" ID="ID_1521058889" MODIFIED="1596263779780" TEXT="&#xd130;&#xbcf4;&#xd615;"/>
<node CREATED="1596263473239" ID="ID_92324161" MODIFIED="1596263475071" TEXT="&#xc124;&#xce58; &#xacbd;&#xc6b0;">
<node CREATED="1596263475872" ID="ID_65657449" MODIFIED="1596263511037" TEXT="&#xbe44;&#xb300;&#xce6d; &#xad50;&#xcc28;&#xb85c;, 4&#xc9c0; &#xc774;&#xc0c1;&#xc758; &#xad50;&#xcc28;&#xb85c;, &#xd2b9;&#xc815; &#xc811;&#xadfc;&#xb85c;&#xc5d0; &#xc6a9;&#xb7c9;&#xc774; &#xacfc;&#xd3ec;&#xd654;&#xb418;&#xc5b4; &#xbd84;&#xc0b0;&#xcc98;&#xb9ac;&#xac00; &#xbc14;&#xb78c;&#xc9c1;&#xd55c; &#xad50;&#xcc28;&#xb85c;, &#xc88c;&#xd68c;&#xc804; &#xd639;&#xc740; &#xc9c1;&#xc9c4; &#xad50;&#xd1b5;&#xb7c9;&#xc774; &#xd2b9;&#xd788; &#xb9ce;&#xc740; &#xad50;&#xcc28;&#xb85c;, &#xb450; &#xac1c;&#xc758; &#xad50;&#xcc28;&#xb85c;&#xac00; &#xb9e4;&#xc6b0; &#xac00;&#xae4c;&#xc6b4; &#xac70;&#xb9ac;&#xc5d0; &#xc778;&#xc811;&#xd55c; &#xacbd;&#xc6b0;"/>
</node>
</node>
<node CREATED="1596262566472" ID="ID_1799489871" MODIFIED="1596262569662" TEXT="&#xc785;&#xccb4;&#xd615; &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596263572508" ID="ID_741330295" MODIFIED="1596263576743" TEXT="&#xb2e8;&#xad6c;&#xd615;">
<node CREATED="1596264065032" ID="ID_747683084" MODIFIED="1596264067270" TEXT="&#xad50;&#xd1b5;&#xc12c; 1&#xac1c;"/>
</node>
<node CREATED="1596263576984" ID="ID_1908671078" MODIFIED="1596263580519" TEXT="&#xc30d;&#xad6c;&#xd615;">
<node CREATED="1596264074902" ID="ID_1067156390" MODIFIED="1596264077266" TEXT="&#xad50;&#xd1b5;&#xc12c; 2&#xac1c;"/>
</node>
<node CREATED="1596263794714" ID="ID_236115848" MODIFIED="1596263797263" TEXT="&#xbb3c;&#xbc29;&#xc6b8;&#xd615;"/>
<node CREATED="1596263797883" ID="ID_1390501441" MODIFIED="1596263800577" TEXT="&#xc124;&#xce58;&#xacbd;&#xc6b0;">
<node CREATED="1596263817054" ID="ID_73695581" MODIFIED="1596263827240" TEXT="&#xc88c;&#xd68c;&#xc804; &#xad50;&#xd1b5;&#xb7c9;&#xc774; &#xb9ce;&#xc740; &#xc5f0;&#xacb0;&#xb85c;">
<node CREATED="1596263828009" ID="ID_270876466" MODIFIED="1596263841146" TEXT="&#xc9c4;&#xcd9c;&#xc785; &#xc790;&#xb3d9;&#xcc28;&#xc758; &#xc6d0;&#xd65c;&#xd55c; &#xcc98;&#xb9ac;&#xac00; &#xac00;&#xb2a5;&#xd558;&#xace0; &#xc8fc;&#xbcc0; &#xc811;&#xadfc;&#xc131; &#xc720;&#xb9ac;"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1596261797993" ID="ID_120126475" MODIFIED="1596263668748" TEXT="&#xad6c;&#xc131; &#xc694;&#xc18c;">
<node CREATED="1596261803317" ID="ID_351500369" MODIFIED="1596261814545" TEXT="&#xc124;&#xacc4; &#xae30;&#xc900; &#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596261853103" ID="ID_926482723" MODIFIED="1596261854402" TEXT="&#xc790;&#xb3d9;&#xcc28;&#xc758; &#xc81c;&#xc6d0;&#xacfc; &#xc6b4;&#xd589; &#xd2b9; &#xc131;&#xc744; &#xb300;&#xd45c;&#xd560; &#xc218; &#xc788;&#xb294; &#xc790;&#xb3d9;&#xcc28;&#xb85c; &#xb3c4;&#xb85c; &#xae30;&#xd558;&#xad6c;&#xc870; &#xc124;&#xacc4; &#xc2dc; &#xc0ac;&#xc6a9;&#xb418;&#xb294; &#xc790;&#xb3d9;&#xcc28;"/>
</node>
<node CREATED="1596261820694" ID="ID_425082001" MODIFIED="1596261823076" TEXT="&#xcc28;&#xb450;&#xc2dc;&#xac04;">
<node CREATED="1596261858325" ID="ID_1198015404" MODIFIED="1596261866102" TEXT=" &#xc784;&#xc758;&#xc758; &#xc9c0;&#xc810;&#xc744; &#xc5f0;&#xc18d;&#xc73c;&#xb85c; &#xd1b5;&#xacfc;&#xd558;&#xb294; &#xc790;&#xb3d9;&#xcc28; &#xac04;&#xc758; &#xc2dc;&#xac04; &#xac04;&#xaca9;&#xc73c;&#xb85c;, &#xc5f0;&#xc18d;&#xc73c;&#xb85c; &#xc624;&#xb294; &#xb450; &#xb300;&#xc758; &#xc790;&#xb3d9;&#xcc28; &#xc911; &#xc120;&#xd589;&#xc790;&#xb3d9;&#xcc28;&#xc758; &#xc55e; &#xbc94;&#xd37c;&#xac00; &#xd1b5;&#xacfc;&#xd55c; &#xc2dc;&#xac01;&#xacfc; &#xd6c4;&#xd589;&#xc790;&#xb3d9;&#xcc28;&#xc758; &#xc55e; &#xbc94;&#xd37c;&#xac00; &#xd1b5;&#xacfc;&#xd55c; &#xc2dc;&#xac01;&#xc744; &#xd55c; &#xc9c0;&#xc810; &#xc5d0;&#xc11c; &#xce21;&#xc815;&#xd55c; &#xc2dc;&#xac01; &#xcc28;&#xc774; "/>
</node>
<node CREATED="1596261823299" ID="ID_824035518" MODIFIED="1596261824493" TEXT="&#xcd94;&#xc885;&#xc2dc;&#xac04;">
<node CREATED="1596261872254" ID="ID_367751961" MODIFIED="1596261873408" TEXT="&#xc9c4;&#xc785;&#xb85c;&#xc5d0;&#xc11c; &#xd68c;&#xc804;&#xcc28;&#xb85c;&#xb85c; &#xc9c4;&#xc785;&#xd558;&#xb294; &#xc790;&#xb3d9;&#xcc28;&#xb4e4; &#xac04;&#xc758; &#xd3c9;&#xade0;&#xcc28;&#xb450;&#xc2dc;&#xac04; "/>
</node>
<node CREATED="1596261824700" ID="ID_332496529" MODIFIED="1596261826164" TEXT="&#xc784;&#xacc4;&#xac04;&#xaca9;">
<node CREATED="1596261876171" ID="ID_1737633571" MODIFIED="1596261881937" TEXT=" &#xc9c4;&#xc785;&#xb85c;&#xc5d0;&#xc11c; &#xd68c;&#xc804;&#xcc28;&#xb85c;&#xb85c; &#xc9c4;&#xc785;&#xc774; &#xac00;&#xb2a5;&#xd55c; &#xc790;&#xb3d9;&#xcc28;&#xb4e4; &#xac04; &#xcc28;&#xb450;&#xc2dc;&#xac04;&#xc758; &#xcd5c;&#xc18c;&#xac12;(&#xc784;&#xacc4;&#xac12;)&#xc73c;&#xb85c;, &#xc77c;&#xbc18;&#xc801;&#xc73c;&#xb85c; &#xc774; &#xac04;&#xaca9;&#xbcf4;&#xb2e4; &#xd06c;&#xba74; &#xc9c4;&#xc785;&#xd560; &#xc218; &#xc788;&#xc73c;&#xb098; &#xc791;&#xc73c;&#xba74; &#xc9c4;&#xc785;&#xd560; &#xc218; &#xc5c6;&#xb294; &#xac04;&#xaca9; "/>
</node>
<node CREATED="1596261826464" ID="ID_1175159621" MODIFIED="1596261829353" TEXT="&#xc911;&#xc559;&#xad50;&#xd1b5;&#xc12c; &#xc9c0;&#xb984;">
<node CREATED="1596261889666" ID="ID_1116631541" MODIFIED="1596261891255" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;&#xc758; &#xc911;&#xc559;&#xc5d0; &#xc124;&#xce58;&#xb41c; &#xc6d0;&#xd615;&#xad50;&#xd1b5;&#xc12c;&#xc758; &#xc9c0;&#xb984;"/>
</node>
<node CREATED="1596261829574" ID="ID_1772311794" MODIFIED="1596261832040" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984;">
<node CREATED="1596261898763" ID="ID_1325189657" MODIFIED="1596261899836" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xb0b4;&#xbd80;&#xc5d0; &#xc811;&#xd558;&#xb3c4;&#xb85d; &#xc124;&#xacc4;&#xd55c; &#xac00;&#xc7a5; &#xd070; &#xc6d0;&#xc758; &#xc9c0;&#xb984;&#xc73c;&#xb85c; &#xb0b4;&#xc811;&#xc6d0;&#xc758; &#xb300;&#xbd80;&#xbd84;&#xc774; &#xd68c;&#xc804;&#xcc28;&#xb85c;&#xc758; &#xc678;&#xacfd;&#xc120; &#xc73c;&#xb85c; &#xc774;&#xb8e8;&#xc5b4;&#xc9c0;&#xbbc0;&#xb85c; &#x2018;&#xd68c;&#xc804;&#xcc28;&#xb85c; &#xbc14;&#xae65;&#xc9c0;&#xb984;&#x2019;&#xc774;&#xb77c;&#xace0;&#xb3c4; &#xd568; "/>
</node>
<node CREATED="1596261832249" ID="ID_1732347027" MODIFIED="1596261833500" TEXT="&#xd68c;&#xc804;&#xcc28;&#xb85c;">
<node CREATED="1596261907196" ID="ID_151508716" MODIFIED="1596261908506" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xb0b4;&#xbd80; &#xd68c;&#xc804;&#xbd80;&#xc758; &#xcc28;&#xb85c; "/>
</node>
<node CREATED="1596261833703" ID="ID_281525034" MODIFIED="1596261923161" TEXT="&#xd68c;&#xc804;&#xcc28;&#xb85c; &#xd3ed;">
<node CREATED="1596261913627" ID="ID_1347931219" MODIFIED="1596261914641" TEXT="&#xd68c;&#xc804;&#xcc28;&#xb85c;&#xc758; &#xd3ed;&#xc73c;&#xb85c; &#xc911;&#xc559; &#xad50;&#xd1b5;&#xc12c;&#xc758; &#xc678;&#xacfd;&#xc5d0;&#xc11c; &#xb0b4;&#xc811;&#xc6d0; &#xc678;&#xacfd;(&#xd68c;&#xc804;&#xcc28;&#xb85c; &#xbc14;&#xae65;&#xc9c0;&#xb984;)&#xae4c;&#xc9c0;&#xc758; &#xb108;&#xbe44; "/>
</node>
<node CREATED="1596261835921" ID="ID_346906734" MODIFIED="1596261839569" TEXT="&#xd654;&#xbb3c;&#xcc28; &#xd131;">
<node CREATED="1596261925323" ID="ID_1349133552" MODIFIED="1596261926213" TEXT=" &#xc911;&#xc559;&#xad50;&#xd1b5;&#xc12c;&#xc758; &#xac00;&#xc7a5;&#xc790;&#xb9ac;&#xc5d0; &#xb300;&#xd615;&#xc790;&#xb3d9;&#xcc28; &#xb610;&#xb294; &#xc138;&#xbbf8;&#xd2b8;&#xb808;&#xc77c;&#xb7ec;&#xac00; &#xbc1f;&#xace0; &#xc9c0;&#xb098;&#xac08; &#xc218; &#xc788;&#xb3c4;&#xb85d; &#xb9cc;&#xb4e0; &#xbd80;&#xbd84;. &#xc124;&#xce58;&#xc5ec;&#xbd80;&#xb294; &#xd574;&#xb2f9; &#xad50;&#xcc28;&#xb85c;&#xc758; &#xae30;&#xb2a5;, &#xc6a9;&#xc9c0; &#xc5ec;&#xac74;, &#xb300;&#xd615;&#xcc28; &#xd63c;&#xc785;&#xc728;&#xc5d0; &#xb530;&#xb77c; &#xc120;&#xd0dd;&#xc801;&#xc73c;&#xb85c; &#xacb0;&#xc815;&#xb418;&#xba70;, &#xd654;&#xbb3c;&#xcc28; &#xd131;&#xc740; &#xc911;&#xc559;&#xad50;&#xd1b5;&#xc12c;&#xc758; &#xc77c;&#xbd80;&#xc784; "/>
</node>
<node CREATED="1596261839788" ID="ID_909175956" MODIFIED="1596261840995" TEXT="&#xc9c4;&#xc785;&#xb85c;">
<node CREATED="1596261931950" ID="ID_535710401" MODIFIED="1596261933197" TEXT=" &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;&#xb85c; &#xc811;&#xadfc;&#xd558;&#xb294; &#xcc28;&#xb85c; "/>
</node>
<node CREATED="1596261841208" ID="ID_476745855" MODIFIED="1596261842206" TEXT="&#xc9c4;&#xcd9c;&#xb85c;">
<node CREATED="1596261938338" ID="ID_1313026770" MODIFIED="1596261939439" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;&#xb85c;&#xbd80;&#xd130; &#xbe60;&#xc838; &#xb098;&#xac00;&#xb294; &#xcc28;&#xb85c;"/>
</node>
<node CREATED="1596261946010" ID="ID_1643353525" MODIFIED="1596261948104" TEXT="&#xbd84;&#xb9ac;&#xad50;&#xd1b5;&#xc12c;">
<node CREATED="1596261972966" ID="ID_988227490" MODIFIED="1596261978568" TEXT=" &#xc790;&#xb3d9;&#xcc28;&#xc758; &#xc9c4;&#xcd9c;&#xc785; &#xbc29;&#xd5a5;&#xc744; &#xc720;&#xb3c4;&#xd558;&#xae30; &#xc704;&#xd574; &#xc9c4;&#xc785;&#xb85c;&#xc640; &#xc9c4;&#xcd9c;&#xb85c; &#xc0ac;&#xc774;&#xc5d0; &#xb9cc;&#xb4e0; &#xc0bc;&#xac01;&#xd615; &#xbaa8;&#xc591;&#xc758; &#xad50;&#xd1b5;&#xc12c;&#xc774;&#xba70; &#xadf8; &#xc2dc;&#xc791;&#xc810;&#xc744; &#xc2dc;&#xc791;&#xb2e8;&#xbd80;(Nose)&#xb77c; &#xd568; "/>
</node>
<node CREATED="1596261948298" ID="ID_288866379" MODIFIED="1596261954946" TEXT="&#xc9c4;&#xc785; &#xb610;&#xb294; &#xc9c4;&#xcd9c; &#xd68c;&#xc804;&#xbc18;&#xc9c0;&#xb984;">
<node CREATED="1596261984911" ID="ID_448453205" MODIFIED="1596261985761" TEXT="&#xc124;&#xacc4;&#xae30;&#xc900;&#xc790;&#xb3d9;&#xcc28;&#xac00; &#xc9c4;&#xc785;&#x2024;&#xc9c4;&#xcd9c;&#xb85c; &#xace1;&#xc120;&#xbd80;&#xb97c; &#xd1b5;&#xacfc;&#xd560; &#xb54c;, &#xc790;&#xb3d9;&#xcc28;&#xc758; &#xc55e;&#xbc14;&#xd034;&#xac00; &#xc9c0;&#xb098;&#xac00;&#xb294; &#xada4;&#xc801; &#xc911; &#xbc14;&#xae65;&#xcabd;(&#xd070; &#xcabd;) &#xace1;&#xc120;&#xbc18;&#xc9c0;&#xb984; "/>
</node>
<node CREATED="1596261955175" ID="ID_531686732" MODIFIED="1596261995860" TEXT="&#xc591;&#xbcf4;&#xc120;">
<node CREATED="1596261992239" ID="ID_855797460" MODIFIED="1596261993043" TEXT="&#xc9c4;&#xc785;&#xb85c;&#xc5d0;&#xc11c; &#xad50;&#xcc28;&#xb85c; &#xb0b4;&#xbd80;&#xc758; &#xd68c;&#xc804;&#xcc28;&#xb85c;&#xb85c; &#xc9c4;&#xc785;&#xd558;&#xb294; &#xc9c0;&#xc810;&#xc758; &#xc120;&#xc744; &#xb9d0;&#xd558;&#xba70;, &#xc774; &#xc591;&#xbcf4;&#xc120;&#xc5d0;&#xc11c; &#xc9c4;&#xc785;&#xc790;&#xb3d9;&#xcc28;&#xb294; &#xd68c;&#xc804;&#xcc28;&#xb85c;&#xb97c; &#xc8fc;&#xd589;&#xd558;&#xace0; &#xc788;&#xb294; &#xc790;&#xb3d9;&#xcc28;&#xc5d0;&#xac8c; &#xc591;&#xbcf4;&#xd574;&#xc57c; &#xd568; "/>
</node>
<node CREATED="1596261957172" ID="ID_704899463" MODIFIED="1596261959380" TEXT="&#xc6b0;&#xd68c;&#xc804; &#xc804;&#xc6a9;&#xcc28;&#xb85c;">
<node CREATED="1596261997984" ID="ID_18909654" MODIFIED="1596262004167" TEXT=" &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xc5d0;&#xc11c; &#xc6b0;&#xd68c;&#xc804;&#xb9cc;&#xc744; &#xc704;&#xd574; &#xbcc4;&#xb3c4;&#xb85c; &#xb9cc;&#xb4e0; &#xbd80;&#xac00;&#xcc28;&#xb85c;"/>
</node>
<node CREATED="1596261959595" ID="ID_1526936974" MODIFIED="1596261960974" TEXT="&#xc8fc;&#xd589;&#xacbd;&#xb85c;">
<node CREATED="1596262010334" ID="ID_1900450819" MODIFIED="1596262011571" TEXT=" &#xac1c;&#xbcc4; &#xc790;&#xb3d9;&#xcc28;&#xac00; &#xb2e4;&#xb978; &#xc790;&#xb3d9;&#xcc28;&#xc758; &#xac04;&#xc12d; &#xc5c6;&#xc774; &#xc9c4;&#xc785; &#xb85c;&#xc5d0;&#xc11c; &#xad50;&#xcc28;&#xb85c; &#xb0b4; &#xd68c;&#xc804;&#xcc28;&#xb85c;&#xb97c; &#xc9c0;&#xb098; &#xc9c4;&#xcd9c;&#xb85c;&#xae4c;&#xc9c0; &#xc8fc;&#xd589;&#xd560; &#xb54c; &#xc9c0;&#xb098;&#xac8c; &#xb418;&#xb294; &#xd3c9;&#xba74;&#xc0c1;&#xc758; &#xacbd;&#xb85c;&#xc774;&#xba70;, &#xc774; &#xc911; &#xac00;&#xc7a5; &#xbe60;&#xb978; &#xacbd;&#xb85c;&#xb97c; &#xd68c;&#xc804;&#xacbd;&#xb85c;(Vehicle Path Curvature)&#xb77c; &#xd568; "/>
</node>
<node CREATED="1596261961268" ID="ID_112976480" MODIFIED="1596261965257" TEXT="&#xd68c;&#xc804;&#xbc18;&#xc9c0;&#xb984;">
<node CREATED="1596262017657" ID="ID_644858683" MODIFIED="1596262018900" TEXT=" &#xd68c;&#xc804;&#xacbd;&#xb85c;&#xc5d0;&#xc11c; &#xd615;&#xc131;&#xb418;&#xb294; &#xbc18;&#xc9c0;&#xb984; "/>
</node>
<node CREATED="1596261965455" ID="ID_1762252140" MODIFIED="1596261969538" TEXT="&#xc8fc;&#xd589;&#xacbd;&#xb85c; &#xc0c1;&#xcda9;">
<node CREATED="1596262021779" ID="ID_702046560" MODIFIED="1596262026931" TEXT=" 2&#xcc28;&#xb85c;&#xd615; &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;&#xc5d0;&#xc11c; &#xc9c4;&#xc785;&#xb7; &#xcd9c; &#xc2dc; 1&#xb7;2&#xcc28;&#xb85c;&#xc5d0;&#xc11c; &#xc8fc;&#xd589;&#xd558;&#xb294; &#xcc28;&#xb7c9;&#xac04; &#xc0c1;&#xcda9;&#xc774; &#xbc1c;&#xc0dd;&#xd558;&#xb294; &#xd615;&#xc0c1;&#xc784;"/>
</node>
</node>
<node CREATED="1596262058714" ID="ID_1116712157" MODIFIED="1596262060515" TEXT="&#xd2b9;&#xc9d5;">
<node CREATED="1596262062395" ID="ID_1831556457" MODIFIED="1596262153068" TEXT="&#xc9c4;&#xc785;&#xd558;&#xb294; &#xc790;&#xb3d9;&#xcc28;&#xac00; &#xad50;&#xcc28;&#xb85c; &#xb0b4; &#xd68c;&#xc804;&#xcc28;&#xb85c;&#xc5d0;&#xc11c; &#xc8fc;&#xd589; &#xc911;&#xc778; &#xc790;&#xb3d9;&#xcc28;&#xc5d0;&#xac8c; &#xc591;&#xbcf4;&#xd558;&#xb294; &#xac83;&#xc744; &#xae30;&#xbcf8;&#xc6d0;&#xb9ac;&#xb85c; &#xd558;&#xbbc0;&#xb85c; &#xd68c;&#xc804;&#xcc28;&#xb85c; &#xb0b4;&#xc5d0;&#xc11c; &#xd63c;&#xc7a1;&#xc774; &#xbc1c;&#xc0dd;&#xd558;&#xc9c0; &#xc54a;&#xb294;&#xb2e4;">
<icon BUILTIN="full-1"/>
</node>
<node CREATED="1596262087798" ID="ID_1068157787" MODIFIED="1596262156611" TEXT="&#xc9c4;&#xc785;&#xd558;&#xb294; &#xc790;&#xb3d9;&#xcc28;&#xac00; &#xd68c;&#xc804;&#xcc28;&#xb85c;&#xc5d0;&#xc11c; &#xc8fc;&#xd589;&#xd558;&#xb294; &#xc790;&#xb3d9;&#xcc28;&#xb4e4; &#xac04;&#xc758; &#xac04;&#xaca9;&#xc744; &#xc774;&#xc6a9;&#xd558;&#xc5ec; &#xc5f0;&#xc18d;&#xc801;&#xc73c;&#xb85c; &#xc9c4;&#xc785;&#xd558;&#xbbc0;&#xb85c; &#xc77c;&#xc815;&#xc218;&#xc900; &#xad50;&#xd1b5;&#xb7c9; &#xbc94;&#xc704;&#xc5d0;&#xc11c;&#xb294; &#xc2e0;&#xd638;&#xc81c;&#xc5b4;&#xc5d0; &#xc758;&#xd574; &#xc6b4;&#xc601;&#xb418;&#xb294; &#xc2e0;&#xd638;&#xad50;&#xcc28;&#xb85c;&#xc5d0; &#xbe44;&#xd574; &#xb300;&#xae30;&#xc2dc;&#xac04;&#xc774; &#xac10;&#xc18c;&#xb418;&#xace0; &#xc6a9;&#xb7c9;&#xc774; &#xc99d;&#xb300;&#xb41c;&#xb2e4;">
<icon BUILTIN="full-2"/>
</node>
<node CREATED="1596262127495" ID="ID_1450232492" MODIFIED="1596262160076" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;&#xb294; &#xc0c1;&#xcda9;&#xd69f;&#xc218;&#xac00; &#xc801;&#xace0; &#xc9c4;&#xc785;&#xc18d;&#xb3c4;&#xb97c; &#xb0ae;&#xac8c; &#xc124;&#xacc4;&#xd558;&#xc5ec; &#xad50;&#xd1b5;&#xc0ac;&#xace0; &#xbc1c;&#xc0dd;&#xac74;&#xc218;&#xc640; &#xd53c;&#xd574;&#xc815;&#xb3c4;&#xac00; &#xc791;&#xb2e4;">
<icon BUILTIN="full-3"/>
</node>
</node>
<node CREATED="1596256513461" ID="ID_1315106835" MODIFIED="1596451129125" TEXT="&#xcd5c;&#xc801; &#xc785;&#xc9c0; &#xc120;&#xc815; &#xc870;&#xac74;">
<node CREATED="1596258115066" ID="ID_1403669715" MODIFIED="1596260157157" TEXT="&#xacc4;&#xd68d;&#xae30;&#xc900;">
<node CREATED="1596258143398" ID="ID_110840368" MODIFIED="1596260356337" TEXT="&#xd1b5;&#xacfc;&#xad50;&#xd1b5;&#xb7c9;">
<node CREATED="1596260216844" ID="ID_1091839172" MODIFIED="1596260362660" TEXT="&#xc18c;&#xd615;">
<node CREATED="1596260272603" ID="ID_793686891" MODIFIED="1596260274184" TEXT="12,000&#xb300;/&#xc77c; &#xc774;&#xd558;"/>
<node CREATED="1596260363917" ID="ID_1081135233" MODIFIED="1596260377539" TEXT="&#xc18c;&#xd615; &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;&#xb294; &#xbd80;&#xb4dd;&#xc774;&#xd55c; &#xacbd;&#xc6b0;&#xc5d0;&#xb9cc; &#xc801;&#xc6a9;"/>
</node>
<node CREATED="1596260229094" ID="ID_1569892828" MODIFIED="1596260231855" TEXT="1&#xcc28;&#xb85c;&#xd615;">
<node CREATED="1596260279008" ID="ID_1064644565" MODIFIED="1596260280163" TEXT=" 1&#xcc28;&#xb85c;&#xd615;&#xc740; 20,000&#xb300;/&#xc77c; &#xc774;&#xd558;"/>
</node>
<node CREATED="1596260232336" ID="ID_12880552" MODIFIED="1596260234660" TEXT="2&#xcc28;&#xb85c;&#xd615;">
<node CREATED="1596260286994" ID="ID_1341558731" MODIFIED="1596260289186" TEXT=", 2&#xcc28;&#xb85c;&#xd615;&#xc740;  32,000&#xb300;/&#xc77c; &#xc774;&#xd558;"/>
</node>
<node CREATED="1596260543130" ID="ID_1703640205" MODIFIED="1596260545407" TEXT="&#xc758;&#xbbf8;">
<node CREATED="1596260417855" ID="ID_1574161492" MODIFIED="1596260426726" TEXT="&#xac01; &#xc811;&#xadfc;&#xb85c; &#xad50;&#xd1b5;&#xb7c9;&#xc744; &#xd569;&#xd55c; &#xad50;&#xcc28;&#xb85c; &#xc804;&#xccb4; &#xad50;&#xd1b5;&#xb7c9;"/>
</node>
</node>
</node>
<node CREATED="1596260588499" ID="ID_463414154" MODIFIED="1596261314308" TEXT="&#xc804;&#xd658;&#xae30;&#xc900;">
<node CREATED="1596260831474" ID="ID_1694233959" MODIFIED="1596523614410" TEXT="&#xad50;&#xd1b5;&#xc18c;&#xd1b5; &#xce21;&#xba74;">
<icon BUILTIN="button_ok"/>
<node CREATED="1596260871907" ID="ID_1145198389" MODIFIED="1596260974380">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#44060;&#48324;&#51652;&#51077;&#47196;&#51032; &#52264;&#47196;&#45817; &#44368;&#53685;&#47049;&#51060; 450&#45824;/&#49884; &#51060;&#54616;<br />-&gt; &#51204;&#54872;&#49884;&#160;&#44368;&#53685;&#49548;&#53685; &#50756;&#54868;<br />
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1596261029370" ID="ID_453778386" MODIFIED="1596261073494">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#51340;&#54924;&#51204; &#44368;&#53685;&#47049; &#48708;&#50984;&#51060; 30~40% &#51060;&#49345;<br />-&gt; &#49888;&#54840;&#44368;&#52264;&#47196;&#44032;&#160;&#48148;&#46988;&#51649;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1596261111591" ID="ID_1130725386" MODIFIED="1596261193747">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#44368;&#53685;&#47049; &#47588;&#50864; &#51201;&#51008; &#44221;&#50864;, &#52264;&#47196;&#45817; 100&#45824;/&#49884; &#48120;&#47564;<br />-&gt;&#48708;&#49888;&#54840; &#44368;&#52264;&#47196;&#44032; &#48148;&#46988;&#51649;
    </p>
  </body>
</html></richcontent>
<node CREATED="1596261215339" ID="ID_578255127" MODIFIED="1596261224450" TEXT="&#xad50;&#xd1b5;&#xc548;&#xc815;&#xc0c1; &#xbb38;&#xc81c;&#xac00; &#xc788;&#xb294; &#xacbd;&#xc6b0;">
<node CREATED="1596261227653" ID="ID_1125200251" MODIFIED="1596261239331" TEXT="&#xc18c;&#xd615; &#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xc801;&#xc6a9; &#xc720;&#xb9ac;"/>
</node>
</node>
</node>
<node CREATED="1596261319192" ID="ID_1396306852" MODIFIED="1596268215022" TEXT="&#xad50;&#xd1b5;&#xc548;&#xc804; &#xce21;&#xba74;">
<icon BUILTIN="button_ok"/>
<node CREATED="1596263041623" ID="ID_1181466110" MODIFIED="1596263105487" TEXT="&#xc704; &#xad50;&#xd1b5;&#xc18c;&#xd1b5; &#xce21;&#xba74;&#xc5d0; &#xbd80;&#xd569;&#xb418;&#xc9c0; &#xc54a;&#xb354;&#xb77c;&#xb3c4; &#xc804;&#xd658; &#xac00;&#xb2a5;">
<node CREATED="1596263116293" ID="ID_458397695" MODIFIED="1596263121446" TEXT="&#xad50;&#xd1b5;&#xc0ac;&#xace0; &#xc7a6;&#xc740; &#xacf3;&#xc73c;&#xb85c; &#xc9c0;&#xc815;&#xb41c; &#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596263121901" ID="ID_734273092" MODIFIED="1596263217379" TEXT="&#xad50;&#xcc28;&#xb85c;&#xc758; &#xc0ac;&#xace0;&#xc720;&#xd615; &#xc911; &#xc9c1;&#xac01; &#xcda9;&#xb3cc; &#xc0ac;&#xace0;/&#xc815;&#xba74; &#xcda9;&#xb3cc;&#xc0ac;&#xace0;&#xac00; &#xbe48;&#xbc88;&#xd788; &#xbc1c;&#xc0dd;&#xd558;&#xb294; &#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596263219599" ID="ID_1032223957" MODIFIED="1596263223552" TEXT="&#xc9c1;&#xac01;&#xcda9;&#xb3cc;&#xc0ac;&#xace0;"/>
<node CREATED="1596263223982" ID="ID_1852437019" MODIFIED="1596263226344" TEXT="&#xc815;&#xba74;&#xcda9;&#xb3cc;&#xc0ac;&#xace0;"/>
</node>
<node CREATED="1596263147679" ID="ID_1415530535" MODIFIED="1596263155501" TEXT="&#xc8fc;&#xb3c4;&#xb85c;&#xc640; &#xbd80;&#xb3c4;&#xb85c;&#xc758; &#xd1b5;&#xd589;&#xc18d;&#xb3c4;&#xcc28;&#xac00; &#xd070; &#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596263160066" ID="ID_262730527" MODIFIED="1596263209471">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#49900;&#44033;&#46020;&#44032; &#45458;&#51008; &#44368;&#53685;&#49324;&#44256; &#48156;&#49373;&#44368;&#52264;&#47196;
    </p>
  </body>
</html></richcontent>
<node CREATED="1596263167439" ID="ID_1033259784" MODIFIED="1596263184891" TEXT="&#xc911;&#xc0c1;&#xc790; &#xbc1c;&#xc0dd; &#xc0ac;&#xace0;"/>
<node CREATED="1596263185537" ID="ID_1372788443" MODIFIED="1596263188710" TEXT="&#xc0ac;&#xb9dd;&#xc790; &#xbc1c;&#xc0dd; &#xc0ac;&#xace0;"/>
</node>
</node>
</node>
</node>
<node CREATED="1596263274027" ID="ID_1399314967" MODIFIED="1596263278127" TEXT="&#xacc4;&#xd68d;&#xc808;&#xcc28;">
<node CREATED="1596263284980" ID="ID_1812602117" MODIFIED="1596268113135" TEXT=" &#xd2b9;&#xc131;&#xbd84;&#xc11d;">
<icon BUILTIN="full-1"/>
<node CREATED="1596263414119" ID="ID_1871649751" MODIFIED="1596263472680" TEXT="&#xad50;&#xcc28;&#xb85c; &#xae30;&#xd558;&#xad6c;&#xc870;"/>
<node CREATED="1596263423396" ID="ID_844447145" MODIFIED="1596263431786" TEXT="&#xae30;&#xd558;&#xad6c;&#xc870;&#xc5d0; &#xb530;&#xb978; &#xac1c;&#xb7b5;&#xc801; &#xc6a9;&#xb7c9;"/>
<node CREATED="1596263432080" ID="ID_1461960464" MODIFIED="1596263488360" TEXT="&#xad50;&#xd1b5;&#xb7c9; &#xbc0f; &#xc9c0;&#xccb4; &#xd604;&#xd669;"/>
<node CREATED="1596263436222" ID="ID_133663225" MODIFIED="1596263453222" TEXT="&#xc2e0;&#xd638; &#xbc0f; &#xad50;&#xd1b5;&#xc6b4;&#xc601;, &#xc8fc;&#xbcc0; &#xad50;&#xcc28;&#xb85c; &#xad50;&#xd1b5;&#xc6b4;&#xc601; &#xd604;&#xd669;"/>
<node CREATED="1596263454138" ID="ID_1338716843" MODIFIED="1596263459453" TEXT="&#xad50;&#xcc28;&#xb85c; &#xc0ac;&#xace0;&#xbc1c;&#xc0dd; &#xac74;&#xc218; &#xbc0f; &#xc0ac;&#xace0; &#xc720;&#xd615;"/>
</node>
<node CREATED="1596263289301" ID="ID_373474338" MODIFIED="1596268119879" TEXT="&#xacc4;&#xd68d; &#xc218;&#xb9bd;">
<icon BUILTIN="full-2"/>
<node CREATED="1596263491277" ID="ID_1025470962" MODIFIED="1596263494575" TEXT="&#xc704;&#xce58; &#xc801;&#xc808;&#xc131;"/>
<node CREATED="1596263495109" ID="ID_238990678" MODIFIED="1596263528464" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xc720;&#xd615;"/>
<node CREATED="1596263528983" ID="ID_725401354" MODIFIED="1596263535693" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c; &#xaddc;&#xbaa8;"/>
<node CREATED="1596263536799" ID="ID_965714304" MODIFIED="1596263538474" TEXT="&#xcc28;&#xb85c; &#xad6c;&#xc131;"/>
</node>
<node CREATED="1596263292794" ID="ID_490393422" MODIFIED="1596268126544" TEXT="&#xc6b4;&#xc601;&#xbc29;&#xc548; &#xc218;&#xb9bd;">
<icon BUILTIN="full-3"/>
<node CREATED="1596263659862" ID="ID_1426739673" MODIFIED="1596263672775" TEXT="&#xc815;&#xd655;&#xd55c; &#xc6a9;&#xb7c9; &#xc0b0;&#xc815;"/>
<node CREATED="1596263698587" ID="ID_1889981693" MODIFIED="1596263731943" TEXT="&#xc811;&#xadfc;&#xb85c;&#xbcc4; &#xad50;&#xd1b5;&#xb7c9; &#xbd84;&#xd3ec; &#xc870;&#xc0ac;"/>
<node CREATED="1596263732391" ID="ID_740516030" MODIFIED="1596263738845" TEXT="&#xbcf4;&#xd589;&#xc790; &#xbc0f; &#xc790;&#xc804;&#xac70; &#xd1b5;&#xd589;&#xb7c9; &#xc870;&#xc0ac;"/>
</node>
<node CREATED="1596263297300" ID="ID_784226376" MODIFIED="1596268131905" TEXT="&#xae30;&#xd558;&#xad6c;&#xc870; &#xc124;&#xacc4;">
<icon BUILTIN="full-4"/>
<node CREATED="1596264096549" ID="ID_443801661" MODIFIED="1596264104185" TEXT="&#xc6b4;&#xc601;&#xbc29;&#xc548; &#xbc0f; &#xc548;&#xc804;&#xc131; &#xac80;&#xd1a0;"/>
</node>
<node CREATED="1596263301434" ID="ID_1731296094" MODIFIED="1596268178516" TEXT="&#xc548;&#xc804;&#xc131; &#xc810;&#xac80;">
<icon BUILTIN="full-5"/>
<node CREATED="1596264281342" ID="ID_709540244" MODIFIED="1596264285750" TEXT="&#xc2dc;&#xbbac;&#xb808;&#xc774;&#xc158; &#xbd84;&#xc11d;"/>
</node>
<node CREATED="1596263307502" FOLDED="true" ID="ID_896350201" MODIFIED="1596268156319" TEXT="&#xcd5c;&#xc885; &#xc124;&#xacc4;">
<icon BUILTIN="full-6"/>
<node CREATED="1596264315072" ID="ID_1739031355" MODIFIED="1596264324600" TEXT="&#xc6b4;&#xc601;&#xbc29;&#xc2dd; &#xbc0f; &#xc548;&#xc804;&#xc131; &#xc810;&#xac80; &#xacb0;&#xacfc;&#xb97c; &#xae30;&#xd558;&#xad6c;&#xc870; &#xc124;&#xacc4;&#xc5d0; &#xbc18;&#xc601;"/>
<node CREATED="1596264325897" ID="ID_341567282" MODIFIED="1596264335925" TEXT="&#xd45c;&#xc9c0;, &#xb178;&#xba74; &#xd45c;&#xc2dc;, &#xc870;&#xba85;, &#xc870;&#xacbd; &#xb4f1;&#xc758; &#xc548;&#xc804;&#xc2dc;&#xc124;&#xacfc; &#xbd80;&#xb300;&#xc2dc;&#xc124;&#xc744; &#xc124;&#xacc4;"/>
</node>
</node>
<node CREATED="1596258535500" ID="ID_1093577898" MODIFIED="1596258887105" TEXT="&#xc124;&#xce58;&#xac00; &#xad8c;&#xc7a5;&#xb418;&#xb294; &#xacbd;&#xc6b0;">
<node CREATED="1596258265958" ID="ID_1291538111" MODIFIED="1596258272559" TEXT="&#xad50;&#xd1b5;&#xb7c9;">
<node CREATED="1596258278239" ID="ID_1639909047" MODIFIED="1596258293151" TEXT="&#xad50;&#xd1b5;&#xb7c9;&#xc774; &#xb9ce;&#xc740; &#xbe44;&#xc2e0;&#xd638; &#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258296669" ID="ID_1321989009" MODIFIED="1596258308334" TEXT="&#xad50;&#xd1b5;&#xb7c9;&#xc774; &#xc801;&#xc740; &#xc2e0;&#xd638;&#xad50;&#xcc28;&#xb85c;"/>
</node>
<node CREATED="1596258324443" ID="ID_744893672" MODIFIED="1596258330322" TEXT="&#xc0ac;&#xace0;&#xbc1c;&#xc0dd; &#xbe48;&#xb3c4;">
<node CREATED="1596258337934" ID="ID_1326467352" MODIFIED="1596258421919" TEXT="&#xc0ac;&#xace0;&#xbc1c;&#xc0dd; &#xbe48;&#xb3c4; &#xb192;&#xc740; &#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258352319" ID="ID_1930209318" MODIFIED="1596258425524" TEXT="&#xc0ac;&#xace0; &#xc2ec;&#xac01;&#xb3c4; &#xb192;&#xc740; &#xad50;&#xcc28;&#xb85c;"/>
</node>
<node CREATED="1596258362925" ID="ID_221245385" MODIFIED="1596258474273" TEXT="&#xad50;&#xcc28;&#xb85c; &#xbbf8;&#xad00;/&#xc720;&#xc9c0;&#xad00;&#xb9ac; &#xbe44;&#xc6a9;">
<node CREATED="1596258397965" ID="ID_1143656408" MODIFIED="1596258438364" TEXT="&#xbbf8;&#xad00;&#xc774; &#xc88b;&#xc9c0; &#xc54a;&#xc740; &#xad50;&#xcc28;&#xb85c; "/>
<node CREATED="1596258449852" ID="ID_1790170230" MODIFIED="1596258486680" TEXT="&#xc720;&#xc9c0;&#xad00;&#xb9ac; &#xbe44;&#xc6a9;&#xc774; &#xb192;&#xc740; &#xad50;&#xcc28;&#xb85c;"/>
</node>
<node CREATED="1596258680278" ID="ID_1318076668" MODIFIED="1596258683385" TEXT="&#xad50;&#xcc28;&#xb85c; &#xd615;&#xd0dc;">
<node CREATED="1596258689165" ID="ID_1313437446" MODIFIED="1596258701511" TEXT="Y&#xc790;&#xd615; &#xad50;&#xcc28;&#xb85c;"/>
<node CREATED="1596258707149" ID="ID_223963288" MODIFIED="1596258712258" TEXT="T&#xc790;&#xd615; &#xad50;&#xcc28;&#xb85c;"/>
</node>
<node CREATED="1596258740331" ID="ID_1605220767" MODIFIED="1596258742250" TEXT="&#xb300;&#xae30;&#xc2dc;&#xac04;">
<node CREATED="1596258744882" ID="ID_193459174" MODIFIED="1596258758112" TEXT="&#xbd88;&#xd544;&#xc694;&#xd55c; &#xc2e0;&#xd638;&#xb300;&#xae30; &#xc2dc;&#xac04;&#xc774; &#xae34; &#xc2e0;&#xd638;&#xad50;&#xcc28;&#xb85c;"/>
</node>
<node CREATED="1596258772925" ID="ID_784265746" MODIFIED="1596258782608" TEXT="&#xad50;&#xd1b5;&#xc815;&#xc628;&#xd654; &#xc0ac;&#xc5c5; &#xad6c;&#xac04; &#xb0b4; &#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596258823780" ID="ID_1034599148" MODIFIED="1596258831785" TEXT="&#xad50;&#xd1b5; &#xc815;&#xc628;&#xd654;">
<node CREATED="1596258833531" ID="ID_1915751801" MODIFIED="1596258834499" TEXT="&#xcc28;&#xb7c9; &#xc18d;&#xb3c4;&#xc640; &#xad50;&#xd1b5;&#xb7c9;&#xc744; &#xc904;&#xc5ec; &#xbcf4;&#xd589;&#xc790; &#xbc0f; &#xc790;&#xc804;&#xac70; &#xc774;&#xc6a9;&#xc790;&#xc758; &#xb3c4;&#xb85c; &#xc774;&#xc6a9;&#xc774; &#xc548;&#xc804;&#xd558;&#xace0; &#xd3b8;&#xb9ac;&#xd558;&#xac8c; &#xb9cc;&#xb4e4;&#xace0;, &#xc18c;&#xc74c;&#xc774;&#xb098; &#xb300;&#xae30;&#xc624;&#xc5fc;&#xc73c;&#xb85c; &#xbd80;&#xd130; &#xc0dd;&#xd65c;&#xad8c;&#xc744; &#xbcf4;&#xd638;&#xd558;&#xb294; &#xac83;"/>
</node>
</node>
</node>
<node CREATED="1596258891241" ID="ID_1581913750" MODIFIED="1596258948849" TEXT="&#xc124;&#xce58;&#xac00; &#xae08;&#xc9c0;&#xb418;&#xb294; &#xacbd;&#xc6b0;">
<node CREATED="1596258897214" ID="ID_1251439165" MODIFIED="1596258917614" TEXT="&#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c; &#xc124;&#xacc4;&#xae30;&#xc900; &#xbbf8;&#xb2ec;">
<node CREATED="1596258918771" ID="ID_899018706" MODIFIED="1596258923144" TEXT="&#xd68c;&#xc804; &#xbc18;&#xc9c0;&#xb984;"/>
<node CREATED="1596258925012" ID="ID_604967483" MODIFIED="1596266126776" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984;">
<node CREATED="1596265596888" ID="ID_1836761509" MODIFIED="1596265602707" TEXT="&#xc18c;&#xd615; &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596265796778" ID="ID_305442349" MODIFIED="1596265799881" TEXT="&#xc18c;&#xd615;&#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596265624170" ID="ID_1504257561" MODIFIED="1596265676347" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 10km/h">
<node CREATED="1596265693363" ID="ID_108943192" MODIFIED="1596265751719" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; : 15.0~18.5 (m)"/>
</node>
<node CREATED="1596265677241" ID="ID_464540561" MODIFIED="1596265683911" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 15km/h">
<node CREATED="1596265712713" ID="ID_1772641635" MODIFIED="1596265756907" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; : 19.0~22.5 (m)"/>
</node>
<node CREATED="1596265678686" ID="ID_1459392543" MODIFIED="1596265688632" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 20km/h">
<node CREATED="1596265729958" ID="ID_835039537" MODIFIED="1596265760430" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; : 23.0~26.0 (m)"/>
</node>
</node>
</node>
<node CREATED="1596265605329" ID="ID_352058229" MODIFIED="1596265608926" TEXT="1&#xcc28;&#xb85c;&#xd615; &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596265804915" ID="ID_907800735" MODIFIED="1596265807524" TEXT="&#xb300;&#xd615;&#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596265678686" ID="ID_1985516316" MODIFIED="1596265688632" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 20km/h">
<node CREATED="1596265729958" ID="ID_1950978438" MODIFIED="1596265844551" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; : 27.0~40.5 (m)"/>
</node>
<node CREATED="1596265678686" ID="ID_1011472144" MODIFIED="1596265833872" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 30km/h">
<node CREATED="1596265729958" ID="ID_1285456703" MODIFIED="1596265869109" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; : 41.0~50.0 (m)"/>
</node>
</node>
<node CREATED="1596265808213" ID="ID_946422020" MODIFIED="1596265810131" TEXT="&#xc138;&#xbbf8;&#xd2b8;&#xb808;&#xc77c;&#xb7ec;">
<node CREATED="1596265678686" ID="ID_1263044062" MODIFIED="1596265688632" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 20km/h">
<node CREATED="1596265729958" ID="ID_1743937601" MODIFIED="1596265884256" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; : 30.0~46.5 (m)"/>
</node>
<node CREATED="1596265678686" ID="ID_697727706" MODIFIED="1596265904359" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 30km/h">
<node CREATED="1596265729958" ID="ID_379969458" MODIFIED="1596265892598" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; : 47.0&#x223c;55.0 (m)"/>
</node>
</node>
</node>
<node CREATED="1596265609271" ID="ID_1876030937" MODIFIED="1596265613051" TEXT="2&#xcc28;&#xb85c;&#xd615; &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596265951145" ID="ID_1366792394" MODIFIED="1596265952915" TEXT="&#xc18c;&#xd615;&#xc790;&#xb3d9;&#xcc28; + &#xb300;&#xd615;&#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596265678686" ID="ID_1363589246" MODIFIED="1596265688632" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 20km/h">
<node CREATED="1596265729958" ID="ID_581233174" MODIFIED="1596266035295" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; : 38.0&#x223c;49.5 (m)"/>
</node>
<node CREATED="1596265678686" ID="ID_865867121" MODIFIED="1596265904359" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 30km/h">
<node CREATED="1596265729958" ID="ID_1859354360" MODIFIED="1596266042562" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; : 50.0&#x223c;60.0 (m)"/>
</node>
</node>
<node CREATED="1596265953326" ID="ID_1088557641" MODIFIED="1596265958581" TEXT="&#xb300;&#xd615;&#xc790;&#xb3d9;&#xcc28; + &#xc138;&#xbbf8;&#xd2b8;&#xb808;&#xc77c;&#xb7ec; ">
<node CREATED="1596265678686" ID="ID_1151971275" MODIFIED="1596265688632" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 20km/h">
<node CREATED="1596265729958" ID="ID_795557571" MODIFIED="1596266047919" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; :  45.0&#x223c;60.5 (m)"/>
</node>
<node CREATED="1596265678686" ID="ID_1840939038" MODIFIED="1596265904359" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 30km/h">
<node CREATED="1596265729958" ID="ID_1512386042" MODIFIED="1596266058118" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; : 61.0&#x223c;65.0 (m)"/>
</node>
</node>
<node CREATED="1596265964997" ID="ID_1514165968" MODIFIED="1596265965996" TEXT="&#xc138;&#xbbf8;&#xd2b8;&#xb808;&#xc77c;&#xb7ec; + &#xc138;&#xbbf8;&#xd2b8;&#xb808;&#xc77c;&#xb7ec; ">
<node CREATED="1596265678686" ID="ID_188312086" MODIFIED="1596265688632" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 20km/h">
<node CREATED="1596265729958" ID="ID_811731477" MODIFIED="1596266067025" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; :  45.0&#x223c;60.5  (m)"/>
</node>
<node CREATED="1596265678686" ID="ID_236817079" MODIFIED="1596265904359" TEXT="&#xd68c;&#xc804;&#xbd80; &#xc124;&#xacc4;&#xc18d;&#xb3c4; : 30km/h">
<node CREATED="1596265729958" ID="ID_1177891879" MODIFIED="1596266080162" TEXT="&#xb0b4;&#xc811;&#xc6d0; &#xc9c0;&#xb984; :61.0&#x223c;65.0  (m)"/>
</node>
</node>
</node>
</node>
<node CREATED="1596258927762" ID="ID_963580545" MODIFIED="1596258928918" TEXT="&#xb3c4;&#xb85c;&#xd3ed;">
<node CREATED="1596266092953" ID="ID_749934862" MODIFIED="1596266205307" TEXT="&#xc9c4;&#xc785;&#xcc28;&#xb85c;(&#xc8fc;&#xb3c4;&#xb85c;) &#xcd5c;&#xc18c; &#xd3ed;">
<node CREATED="1596265596888" ID="ID_262638334" MODIFIED="1596265602707" TEXT="&#xc18c;&#xd615; &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596265796778" ID="ID_200716468" MODIFIED="1596265799881" TEXT="&#xc18c;&#xd615;&#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596265624170" ID="ID_700295721" MODIFIED="1596266211728" TEXT="2.9m"/>
</node>
</node>
<node CREATED="1596265605329" ID="ID_558341206" MODIFIED="1596265608926" TEXT="1&#xcc28;&#xb85c;&#xd615; &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596265804915" ID="ID_1286725077" MODIFIED="1596265807524" TEXT="&#xb300;&#xd615;&#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596265678686" ID="ID_951338036" MODIFIED="1596266261655" TEXT="3.9m"/>
</node>
<node CREATED="1596265808213" ID="ID_593329553" MODIFIED="1596265810131" TEXT="&#xc138;&#xbbf8;&#xd2b8;&#xb808;&#xc77c;&#xb7ec;">
<node CREATED="1596265678686" ID="ID_722432258" MODIFIED="1596266266943" TEXT="4.5m"/>
</node>
</node>
<node CREATED="1596265609271" ID="ID_597093051" MODIFIED="1596265613051" TEXT="2&#xcc28;&#xb85c;&#xd615; &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;">
<node CREATED="1596265951145" ID="ID_643789393" MODIFIED="1596265952915" TEXT="&#xc18c;&#xd615;&#xc790;&#xb3d9;&#xcc28; + &#xb300;&#xd615;&#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596265678686" ID="ID_781199862" MODIFIED="1596266273379" TEXT="8.2m"/>
</node>
<node CREATED="1596265953326" ID="ID_455142420" MODIFIED="1596265958581" TEXT="&#xb300;&#xd615;&#xc790;&#xb3d9;&#xcc28; + &#xc138;&#xbbf8;&#xd2b8;&#xb808;&#xc77c;&#xb7ec; ">
<node CREATED="1596265678686" ID="ID_1074663341" MODIFIED="1596266278032" TEXT="9.7m"/>
</node>
<node CREATED="1596265964997" ID="ID_1314880857" MODIFIED="1596265965996" TEXT="&#xc138;&#xbbf8;&#xd2b8;&#xb808;&#xc77c;&#xb7ec; + &#xc138;&#xbbf8;&#xd2b8;&#xb808;&#xc77c;&#xb7ec; ">
<node CREATED="1596265678686" ID="ID_477419762" MODIFIED="1596266282603" TEXT="9.5m"/>
</node>
</node>
</node>
</node>
<node CREATED="1596258929554" ID="ID_75975005" MODIFIED="1596258941851" TEXT="&#xacbd;&#xc0ac;&#xb3c4;">
<node CREATED="1596265485034" ID="ID_1009384211" MODIFIED="1596265496805" TEXT="&#xc811;&#xadfc;&#xb85c;&#xc758; &#xc885;&#xb2e8;&#xacbd;&#xc0ac;&#xac00; 3% &#xc774;&#xd558;"/>
</node>
</node>
<node CREATED="1596258960578" ID="ID_995910529" MODIFIED="1596258971214" TEXT="&#xcca8;&#xb450;&#xc2dc; &#xac00;&#xbcc0;&#xcc28;&#xb85c;&#xac00; &#xc6b4;&#xc601;">
<node CREATED="1596258973202" ID="ID_1574493108" MODIFIED="1596258976214" TEXT="&#xcca8;&#xb450;&#xc2dc;">
<node CREATED="1596259003332" ID="ID_960179184" MODIFIED="1596259004350" TEXT="&#xd558;&#xb8e8;&#xc911; &#xcd5c;&#xace0;&#xb85c; &#xb9ce;&#xc740; &#xc778;&#xc6d0;&#xc774;&#xb098; &#xcc28;&#xb7c9;&#xc774; &#xd1b5;&#xd589;&#xd558;&#xb294; &#xc2dc;&#xac04;&#xb300;"/>
<node CREATED="1596259028082" ID="ID_1707133325" MODIFIED="1596259038739" TEXT="&#xac00;&#xbcc0;&#xcc28;&#xb85c;&#xb294; &#xc591;&#xbc29;&#xd5a5; &#xb3c4;&#xb85c;&#xc758; &#xd1b5;&#xd589;&#xb7c9;&#xc774; &#xc77c;&#xc815;&#xd558;&#xc9c0; &#xc54a;&#xc744; &#xb54c; 1&#xcc28;&#xb85c; &#xb610;&#xb294; 2&#xcc28;&#xb85c;&#xc758; &#xd1b5;&#xd589; &#xbc29;&#xd5a5;&#xc744; &#xc790;&#xb3d9; &#xb610;&#xb294; &#xc218;&#xb3d9;&#xc73c;&#xb85c; &#xbc14;&#xafb8;&#xc5b4; &#xc0ac;&#xc6a9;&#xd560; &#xc218; &#xc788;&#xb294; &#xae38;"/>
</node>
</node>
<node CREATED="1596259569932" ID="ID_73846802" MODIFIED="1596259591559" TEXT="&#xc2e0;&#xd638;&#xc5f0;&#xb3d9;&#xb41c; &#xad6c;&#xac04;">
<node CREATED="1596259600834" ID="ID_677088317" MODIFIED="1596259613647" TEXT="&#xc2e0;&#xd638;&#xc5f0;&#xb3d9;&#xc774; &#xc774;&#xb8e8;&#xc5b4;&#xc9c0;&#xace0; &#xc788;&#xb294; &#xad6c;&#xac04; &#xb0b4; &#xad50;&#xcc28;&#xb85c;&#xb97c; &#xd68c;&#xc804; &#xad50;&#xcc28;&#xb85c;&#xb85c; &#xc804;&#xd658;&#xc2dc; &#xc5f0;&#xb3d9;&#xd6a8;&#xacfc;&#xb97c; &#xac10;&#xc18c;&#xc2dc;&#xd0ac; &#xc218; &#xc788;&#xb294; &#xacbd;&#xc6b0;"/>
</node>
<node CREATED="1596259620941" ID="ID_1511685864" MODIFIED="1596259624522" TEXT="&#xad50;&#xd1b5;&#xb7c9;">
<node CREATED="1596259631094" ID="ID_1579916015" MODIFIED="1596259641884" TEXT="&#xd68c;&#xc804;&#xad50;&#xcc28;&#xb85c;&#xc758; &#xad50;&#xd1b5;&#xb7c9; &#xc218;&#xc900;&#xc774; &#xcc98;&#xb9ac;&#xc6a9;&#xb7c9;&#xc744; &#xcd08;&#xacfc;&#xd558;&#xb294; &#xacbd;&#xc6b0;"/>
</node>
<node CREATED="1596259679074" ID="ID_278597267" MODIFIED="1596259686691" TEXT="&#xc811;&#xadfc;&#xb85c;">
<node CREATED="1596259688877" ID="ID_1374572241" MODIFIED="1596259697362" TEXT="&#xad50;&#xcc28;&#xb85c;&#xc5d0;&#xc11c; &#xd558;&#xb098; &#xc774;&#xc0c1;&#xc758; &#xc811;&#xadfc;&#xb85c;&#xac00; &#xd3b8;&#xb3c4; 3&#xcc28;&#xb85c; &#xc774;&#xc0c1;&#xc778; &#xacbd;&#xc6b0;"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1596449918804" ID="ID_945521675" MODIFIED="1596449924476" TEXT="&#xb3c4;&#xb85c; &#xd655;&#xc7a5;"/>
</node>
<node CREATED="1596444073447" ID="ID_1384614960" MODIFIED="1596444080450" TEXT="&#xc6b4;&#xc804;&#xc790; &#xbc0f; &#xbcf4;&#xd589;&#xc790; &#xc548;&#xc804;&#xad50;&#xc721; &#xac15;&#xd654;"/>
<node CREATED="1596500000077" ID="ID_1882025214" MODIFIED="1596500007873" TEXT="CCTV &#xc124;&#xce58;">
<node CREATED="1596500008969" ID="ID_1715328174" MODIFIED="1596500018439" TEXT="&#xc18d;&#xb3c4; &#xc704;&#xbc18; &#xcc28;&#xb7c9; &#xb2e8;&#xc18d; CCTV">
<node CREATED="1596522522932" ID="ID_834899482" MODIFIED="1596522543310" TEXT="2016&#xb144; 2910 -&gt; 2019&#xb144; 3486"/>
</node>
<node CREATED="1596500018910" ID="ID_242638517" MODIFIED="1596500028025" TEXT="&#xc2e0;&#xd638; &#xc704;&#xbc18; &#xb2e8;&#xc18d; CCTV">
<node CREATED="1596522544902" ID="ID_1718156943" MODIFIED="1596522558767" TEXT="2016&#xb144; 3616 -&gt; 2019&#xb144; 5942"/>
</node>
<node CREATED="1596522469448" ID="ID_1250298843" MODIFIED="1596522521788" TEXT="&#xad6c;&#xac04;&#xc18d;&#xb3c4; &#xc704;&#xbc18; &#xb2e8;&#xc18d; CCTV">
<node CREATED="1596522560355" ID="ID_123639246" MODIFIED="1596522569944" TEXT="2016&#xb144; 328 -&gt; 2019&#xb144; 658"/>
</node>
</node>
<node CREATED="1596500295145" ID="ID_856014093" MODIFIED="1596500301887" TEXT="&#xad50;&#xd1b5; &#xc57d;&#xc790; &#xc8fc;&#xc758; &#xad6c;&#xac04; &#xc0dd;&#xc131;">
<node CREATED="1596500304900" ID="ID_286302668" MODIFIED="1596500307899" TEXT="&#xc2e4;&#xbc84;&#xc874;">
<node CREATED="1596500360850" ID="ID_580655055" MODIFIED="1596500447853" TEXT="&#xad50;&#xd1b5;&#xc57d;&#xc790;&#xc778; &#xb178;&#xc778;&#xc744; &#xad50;&#xd1b5;&#xc0ac;&#xace0; &#xc704;&#xd5d8;&#xc5d0;&#xc11c; &#xbcf4;&#xd638;&#xd558;&#xae30; &#xc704;&#xd574; &#xc591;&#xb85c;&#xc6d0;, &#xacbd;&#xb85c;&#xb2f9;, &#xb178;&#xc778;&#xbcf5;&#xc9c0;&#xc2dc;&#xc124; &#xb4f1; &#xb178;&#xc778;&#xb4e4;&#xc758; &#xd1b5;&#xd589;&#xb7c9;&#xc774; &#xb9ce;&#xc740; &#xad6c;&#xc5ed;&#xc744; &#xc120;&#xc815;&#xd558;&#xc5ec; &#xb178;&#xc778;&#xb4e4;&#xc758; &#xc548;&#xc804;&#xd55c; &#xd1b5;&#xd589;&#xc744; &#xbcf4;&#xc7a5;&#xd558;&#xace0;&#xc790; &#xd558;&#xb294; &#xc9c0;&#xc815;&#xb41c; &#xad50;&#xd1b5;&#xc57d;&#xc790;&#xbcf4;&#xd638;&#xad6c;&#xc5ed;&#xc73c;&#xb85c; &#xc2e4;&#xbc84;&#xc874;&#xc73c;&#xb85c; &#xc120;&#xc815;"/>
</node>
<node CREATED="1596500308270" ID="ID_1006257333" MODIFIED="1596500310130" TEXT="&#xc2a4;&#xcfe8;&#xc874;">
<node CREATED="1596500410413" ID="ID_1453049215" MODIFIED="1596500411522" TEXT="&#xcd08;&#xb4f1;&#xd559;&#xad50; &#xbc0f; &#xc720;&#xce58;&#xc6d0;, &#xc5b4;&#xb9b0;&#xc774;&#xc9d1;, &#xd559;&#xc6d0; &#xb4f1; &#xb9cc; 13&#xc138; &#xbbf8;&#xb9cc; &#xc5b4;&#xb9b0;&#xc774;&#xc2dc;&#xc124; &#xc8fc;&#xbcc0;&#xb3c4;&#xb85c; &#xc911; &#xc77c;&#xc815;&#xad6c;&#xac04;&#xc744; &#xbcf4;&#xd638;&#xad6c;&#xc5ed;&#xc73c;&#xb85c; &#xc9c0;&#xc815;&#xd558;&#xc5ec; &#xad50;&#xd1b5;&#xc548;&#xc804;&#xc2dc;&#xc124;&#xbb3c; &#xbc0f; &#xb3c4;&#xb85c;&#xbd80;&#xc18d;&#xbb3c; &#xc124;&#xce58;&#xb85c; &#xc5b4;&#xb9b0;&#xc774;&#xb4e4;&#xc758; &#xc548;&#xc804;&#xd55c; &#xd1b5;&#xd559;&#xacf5;&#xac04;&#xc744; &#xd655;&#xbcf4;&#xd558;&#xc5ec; &#xad50;&#xd1b5;&#xc0ac;&#xace0;&#xb97c; &#xc608;&#xbc29;&#xd558;&#xae30; &#xc704;&#xd55c; &#xc81c;&#xb3c4;"/>
</node>
</node>
</node>
<node CREATED="1596443745507" ID="ID_963983341" MODIFIED="1596443752034" TEXT="&#xc6d0;&#xc778;">
<node CREATED="1596443893670" ID="ID_1816983147" MODIFIED="1596443916602" TEXT="&#xc6b4;&#xc804;&#xc790; &#xbd80;&#xc8fc;&#xc758;">
<node CREATED="1596450122577" ID="ID_1130424308" MODIFIED="1596450136717" TEXT="27.9%(&#xd1b5;&#xacc4;&#xccad;)"/>
</node>
<node CREATED="1596443916843" ID="ID_22927753" MODIFIED="1596443920959" TEXT="&#xbcf4;&#xd589;&#xc790; &#xbd80;&#xc8fc;&#xc758;">
<node CREATED="1596450138727" ID="ID_1861509803" MODIFIED="1596450206116" TEXT="2.5%(&#xd1b5;&#xacc4;&#xccad;)"/>
</node>
<node CREATED="1596443921243" ID="ID_887173057" MODIFIED="1596443923530" TEXT="&#xad50;&#xd1b5; &#xd63c;&#xc7a1;">
<node CREATED="1596450146731" ID="ID_1392370679" MODIFIED="1596450211370" TEXT="9.4%(&#xd1b5;&#xacc4;&#xccad;)"/>
</node>
<node CREATED="1596443924127" ID="ID_229179483" MODIFIED="1596443942001" TEXT="&#xb3c4;&#xb85c; &#xad6c;&#xc870;&#xc758; &#xc798;&#xbabb;">
<node CREATED="1596450159746" ID="ID_1900323139" MODIFIED="1596450217913" TEXT="3.5%(&#xd1b5;&#xacc4;&#xccad;)"/>
</node>
<node CREATED="1596443942596" ID="ID_1560886777" MODIFIED="1596444033599" TEXT="&#xad50;&#xd1b5;&#xc2e0;&#xd638;&#xccb4;&#xacc4;&#xc758; &#xc798;&#xbabb;">
<node CREATED="1596450173212" ID="ID_626877049" MODIFIED="1596450230093" TEXT="1.8%(&#xd1b5;&#xacc4;&#xccad;)"/>
</node>
<node CREATED="1596450180165" ID="ID_70927767" MODIFIED="1596450189170" TEXT="&#xc6b4;&#xc804;&#xc790;&#xb098; &#xbcf4;&#xd589;&#xc790;&#xc758; &#xc9c8;&#xc11c;&#xc758;&#xc2dd; &#xbd80;&#xc871;">
<node CREATED="1596450190101" ID="ID_97005186" MODIFIED="1596450235575" TEXT="54.8%(&#xd1b5;&#xacc4;&#xccad;)"/>
</node>
</node>
</node>
<node CREATED="1596441243246" ID="ID_1386408979" MODIFIED="1596450517887" POSITION="left" TEXT="&#xbd88;&#xbc95;&#xc8fc;&#xc815;&#xcc28;">
<node CREATED="1595225446900" ID="ID_1627277650" MODIFIED="1596499648014" TEXT="&#xc815;&#xc758;">
<node CREATED="1595226151061" ID="ID_1261726512" MODIFIED="1596450641186" TEXT="&#xc8fc;&#xc815;&#xcc28;(&#xb3c4;&#xb85c;&#xad50;&#xd1b5;&#xbc95; &#xc81c;2&#xc870;)">
<node CREATED="1595226092077" ID="ID_680677283" MODIFIED="1595239525301" TEXT="&#xc8fc;&#xcc28;(&#xb3c4;&#xb85c;&#xad50;&#xd1b5;&#xbc95; &#xc81c; 2&#xc870; 24&#xd638;) ">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="idea"/>
<node CREATED="1595226125053" ID="ID_1074380185" MODIFIED="1595226126541" TEXT="&#xcc28;&#xac00; &#xc2b9;&#xac1d;&#xc744; &#xae30;&#xb2e4;&#xb9ac;&#xac70;&#xb098; &#xd654;&#xbb3c;&#xc744; &#xc2e3;&#xac70;&#xb098; &#xace0;&#xc7a5; &#xadf8; &#xbc16;&#xc758; &#xc0ac;&#xc720;&#xb85c; &#xc778;&#xd558;&#xc5ec; &#xacc4;&#xc18d;&#xd558;&#xc5ec; &#xc815;&#xc9c0;&#xd558;&#xac70;&#xb098; &#xb610;&#xb294; &#xadf8; &#xcc28;&#xc758; &#xc6b4;&#xc804;&#xc790;&#xac00;  &#xadf8; &#xcc28;&#xb85c;&#xbd80;&#xd130; &#xb5a0;&#xb098;&#xc11c; &#xc989;&#xc2dc; &#xc6b4;&#xc804;&#xd560; &#xc218; &#xc5c6;&#xb294; &#xc0c1;&#xd0dc;&#xb97c; &#xb9d0;&#xd55c;&#xb2e4;."/>
</node>
<node CREATED="1595226129349" ID="ID_1411890180" MODIFIED="1595226134507" TEXT="&#xc815;&#xcc28;(&#xb3c4;&#xb85c;&#xad50;&#xd1b5;&#xbc95; &#xc81c;2&#xc870;25&#xd638;)">
<node CREATED="1595226136957" ID="ID_496542498" MODIFIED="1595226141908" TEXT="&#xcc28;&#xac00; 5&#xbd84;&#xc744; &#xcd08;&#xacfc;&#xd558;&#xc9c0; &#xc544;&#xb2c8;&#xd558;&#xace0; &#xc815;&#xc9c0;&#xd558;&#xb294;  &#xac83;&#xc73c;&#xb85c;&#xc11c; &#xc8fc;&#xcc28; &#xc678;&#xc758; &#xc815;&#xc9c0;&#xc0c1;&#xd0dc;&#xb97c; &#xb9d0;&#xd55c;&#xb2e4;."/>
</node>
</node>
<node CREATED="1595226181476" ID="ID_1029317767" MODIFIED="1596450658484" TEXT="&#xc815;&#xcc28; &#xbc0f; &#xc8fc;&#xcc28;&#xc758; &#xae08;&#xc9c0;(&#xb3c4;&#xb85c;&#xad50;&#xd1b5;&#xbc95; &#xc81c;32&#xc870;)">
<node CREATED="1595226245509" ID="ID_878684030" MODIFIED="1595226256741" TEXT="1. &#xad50;&#xcc28;&#xb85c;&#xb7;&#xd6a1;&#xb2e8;&#xbcf4;&#xb3c4;&#xb7;&#xac74;&#xb110;&#xbaa9;&#xc774;&#xb098; &#xbcf4;&#xb3c4;&#xc640; &#xcc28;&#xb3c4;&#xac00; &#xad6c;&#xbd84;&#xb41c; &#xb3c4;&#xb85c;&#xc758; &#xbcf4;&#xb3c4;(&#xc8fc;&#xcc28;&#xc7a5;&#xbc95;&#xc5d0;  &#xb530;&#xb77c; &#xcc28;&#xb3c4;&#xc640; &#xbcf4;&#xb3c4;&#xc5d0; &#xac78;&#xccd0;&#xc11c; &#xc124;&#xce58;&#xb41c; &#xb178;&#xc0c1;&#xc8fc;&#xcc28;&#xc7a5;&#xc740; &#xc81c;&#xc678;&#xd55c;&#xb2e4;)"/>
<node CREATED="1595226258407" ID="ID_415713526" MODIFIED="1595226263315" TEXT="2. &#xad50;&#xcc28;&#xb85c;&#xc758; &#xac00;&#xc7a5;&#xc790;&#xb9ac;&#xb098; &#xb3c4;&#xb85c;&#xc758; &#xbaa8;&#xd241;&#xc774;&#xb85c;&#xbd80;&#xd130; 5&#xbbf8;&#xd130; &#xc774;&#xb0b4;&#xc778; &#xacf3;"/>
<node CREATED="1595226301788" ID="ID_29781244" MODIFIED="1595226306223" TEXT="3. &#xc548;&#xc804;&#xc9c0;&#xb300;&#xac00; &#xc124;&#xce58;&#xb41c; &#xb3c4;&#xb85c;&#xc5d0;&#xc11c;&#xb294; &#xadf8; &#xc548;&#xc804;&#xc9c0;&#xb300;&#xc758; &#xc0ac;&#xbc29;&#xc73c;&#xb85c;&#xbd80;&#xd130; &#xac01;&#xac01; 10&#xbbf8;&#xd130;  &#xc774;&#xb0b4;&#xc778; &#xacf3;"/>
<node CREATED="1595226307068" ID="ID_1496965124" MODIFIED="1595226312643" TEXT="4. &#xbc84;&#xc2a4;&#xc5ec;&#xac1d;&#xc790;&#xb3d9;&#xcc28;&#xc758; &#xc815;&#xb958;&#xc9c0;(&#x505c;&#x7559;&#x5730;)&#xc784;&#xc744; &#xd45c;&#xc2dc;&#xd558;&#xb294; &#xae30;&#xb465;&#xc774;&#xb098; &#xd45c;&#xc9c0;&#xd310; &#xb610;&#xb294;  &#xc120;&#xc774; &#xc124;&#xce58;&#xb41c; &#xacf3;&#xc73c;&#xb85c;&#xbd80;&#xd130; 10&#xbbf8;&#xd130; &#xc774;&#xb0b4;&#xc778; &#xacf3;. &#xb2e4;&#xb9cc;, &#xbc84;&#xc2a4;&#xc5ec;&#xac1d;&#xc790;&#xb3d9;&#xcc28;&#xc758;  &#xc6b4;&#xc804;&#xc790;&#xac00; &#xadf8; &#xbc84;&#xc2a4;&#xc5ec;&#xac1d;&#xc790;&#xb3d9;&#xcc28;&#xc758; &#xc6b4;&#xd589;&#xc2dc;&#xac04; &#xc911;&#xc5d0; &#xc6b4;&#xd589;&#xb178;&#xc120;&#xc5d0; &#xb530;&#xb974;&#xb294;  &#xc815;&#xb958;&#xc7a5;&#xc5d0;&#xc11c; &#xc2b9;&#xac1d;&#xc744; &#xd0dc;&#xc6b0;&#xac70;&#xb098; &#xb0b4;&#xb9ac;&#xae30; &#xc704;&#xd558;&#xc5ec; &#xcc28;&#xb97c; &#xc815;&#xcc28;&#xd558;&#xac70;&#xb098; &#xc8fc;&#xcc28;&#xd558;&#xb294;  &#xacbd;&#xc6b0;&#xc5d0;&#xb294; &#xadf8;&#xb7ec;&#xd558;&#xc9c0; &#xc544;&#xb2c8;&#xd558;&#xb2e4;. "/>
<node CREATED="1595226328285" ID="ID_1571684276" MODIFIED="1595226334692" TEXT="5. &#xac74;&#xb110;&#xbaa9;&#xc758; &#xac00;&#xc7a5;&#xc790;&#xb9ac; &#xb610;&#xb294; &#xd6a1;&#xb2e8;&#xbcf4;&#xb3c4;&#xb85c;&#xbd80;&#xd130; 10&#xbbf8;&#xd130; &#xc774;&#xb0b4;&#xc778; &#xacf3;"/>
<node CREATED="1595226336300" ID="ID_768220835" MODIFIED="1595226341285" TEXT="6. &#xc9c0;&#xbc29;&#xacbd;&#xcc30;&#xccad;&#xc7a5;&#xc774; &#xb3c4;&#xb85c;&#xc5d0;&#xc11c;&#xc758; &#xc704;&#xd5d8;&#xc744; &#xbc29;&#xc9c0;&#xd558;&#xace0; &#xad50;&#xd1b5;&#xc758; &#xc548;&#xc804;&#xacfc; &#xc6d0;&#xd65c;&#xd55c;  &#xc18c;&#xd1b5;&#xc744; &#xd655;&#xbcf4;&#xd558;&#xae30; &#xc704;&#xd558;&#xc5ec; &#xd544;&#xc694;&#xd558;&#xb2e4;&#xace0; &#xc778;&#xc815;&#xd558;&#xc5ec; &#xc9c0;&#xc815;&#xd55c; &#xacf3; (&#xc878;&#xc74c;&#xbc29;&#xc9c0;&#xc27c;&#xd130;)"/>
</node>
<node CREATED="1595226361021" ID="ID_1518848848" MODIFIED="1596450664675" TEXT="&#xc8fc;&#xcc28;&#xae08;&#xc9c0;&#xc758; &#xc7a5;&#xc18c;(&#xb3c4;&#xb85c;&#xad50;&#xd1b5;&#xbc95; 33&#xc870;)">
<node CREATED="1595226381428" ID="ID_285805971" MODIFIED="1595226386816" TEXT="1. &#xd130;&#xb110; &#xc548; &#xbc0f; &#xb2e4;&#xb9ac; &#xc704;"/>
<node CREATED="1595226387270" ID="ID_1633295177" MODIFIED="1595226390886" TEXT="2. &#xd654;&#xc7ac;&#xacbd;&#xbcf4;&#xae30;&#xb85c;&#xbd80;&#xd130; 3&#xbbf8;&#xd130; &#xc774;&#xb0b4;&#xc778; &#xacf3;"/>
<node CREATED="1595226391334" ID="ID_1601326020" MODIFIED="1595226419730" TEXT="3. &#xb2e4;&#xc74c; &#xac01; &#xbaa9;&#xc758; &#xacf3;&#xc73c;&#xb85c;&#xbd80;&#xd130; 5&#xbbf8;&#xd130; &#xc774;&#xb0b4;&#xc778; &#xacf3;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1595226422405" ID="ID_1169736222" MODIFIED="1595226445036" TEXT="&#xac00;,&#xb098;,&#xb2e4;. &#xc18c;&#xbc29;&#xc6a9; &#xae30;&#xacc4;&#xb7;&#xae30;&#xad6c;&#xac00; &#xc124;&#xce58;&#xb41c; &#xacf3;"/>
<node CREATED="1595226430205" ID="ID_1216933265" MODIFIED="1595226452597" TEXT="&#xb77c;. &#xb3c4;&#xb85c;&#xacf5;&#xc0ac;&#xb97c; &#xd558;&#xace0; &#xc788;&#xb294; &#xacbd;&#xc6b0;&#xc5d0;&#xb294; &#xadf8; &#xacf5;&#xc0ac; &#xad6c;&#xc5ed;&#xc758; &#xc591;&#xcabd; &#xac00;&#xc7a5;&#xc790;&#xb9ac;"/>
</node>
<node CREATED="1595226428666" ID="ID_871765557" MODIFIED="1595226463878" TEXT="4. &#xc9c0;&#xbc29;&#xacbd;&#xcc30;&#xccad;&#xc7a5;&#xc774; &#xb3c4;&#xb85c;&#xc5d0;&#xc11c;&#xc758; &#xc704;&#xd5d8;&#xc744; &#xbc29;&#xc9c0;&#xd558;&#xace0; &#xad50;&#xd1b5;&#xc758; &#xc548;&#xc804;&#xacfc; &#xc6d0;&#xd65c;&#xd55c;  &#xc18c;&#xd1b5;&#xc744; &#xd655;&#xbcf4;&#xd558;&#xae30; &#xc704;&#xd558;&#xc5ec; &#xd544;&#xc694;&#xd558;&#xb2e4;&#xace0; &#xc778;&#xc815;&#xd558;&#xc5ec; &#xc9c0;&#xc815;&#xd55c; &#xacf3; "/>
</node>
</node>
<node CREATED="1596450624055" ID="ID_1872641488" MODIFIED="1596450626079" TEXT="&#xd604;&#xd669;">
<node CREATED="1596451322753" ID="ID_893776412" MODIFIED="1596453153668">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#48520;&#48277;&#51452;&#51221;&#52264; &#54788;&#54889;
    </p>
    <p>
      2013&#45380; 22,228&#44148; -&gt; 2017&#45380; 51,489&#44148;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1596453162673" ID="ID_1524694478" MODIFIED="1596453172339" TEXT="&#xbd88;&#xbc95;&#xc8fc;&#xc815;&#xcc28;&#xb85c; &#xc778;&#xd55c; &#xd53c;&#xd574;">
<node CREATED="1596453174180" ID="ID_677336598" MODIFIED="1596453205105" TEXT="&#xbcf4;&#xd589; &#xbd88;&#xd3b8; &#xc7a5;&#xc560; 52%"/>
<node CREATED="1596453205420" ID="ID_1349331624" MODIFIED="1596453260509" TEXT="&#xb3c4;&#xb85c;&#xad50;&#xd1b5;&#xd63c;&#xc7a1; 27.9%"/>
<node CREATED="1596453221990" ID="ID_949203819" MODIFIED="1596453251697" TEXT="&#xad50;&#xd1b5;&#xc0ac;&#xace0; &#xbc1c;&#xc0dd; 7.5%"/>
<node CREATED="1596453252764" ID="ID_1998142660" MODIFIED="1596453292430" TEXT="&#xae34;&#xae09;&#xcd9c;&#xb3d9;&#xcc28;&#xb7c9; &#xd1b5;&#xd589; &#xc7a5;&#xc560; 9.5%"/>
</node>
</node>
<node CREATED="1596450626534" ID="ID_1648277101" MODIFIED="1596450627945" TEXT="&#xb300;&#xcc45;">
<node CREATED="1596453345976" ID="ID_112923095" MODIFIED="1596453347765" TEXT="&#xadf8;&#xb9b0;&#xd30c;&#xd0b9;">
<node CREATED="1596453463169" ID="ID_1737918309" MODIFIED="1596453464293" TEXT="&#xc8fc;&#xd0dd;&#xac00; &#xb2f4;&#xc7a5;&#xc744; &#xd5c8;&#xbb3c;&#xc5b4; &#xc790;&#xac00; &#xc8fc;&#xcc28;&#xc7a5;&#xc744; &#xb9cc;&#xb4e4;&#xace0; &#xc5ec;&#xc720; &#xacf5;&#xac04;&#xc5d0; &#xc218;&#xbaa9; &#xc2dd;&#xc7ac;&#xb97c; &#xc2ec;&#xace0;, &#xc8fc;&#xd0dd;&#xac00; &#xc774;&#xba74; &#xb3c4;&#xb85c;&#xc5d0;&#xb294; &#xc5b4;&#xb9b0;&#xc774;&#xb4e4;&#xc774; &#xc548;&#xc804;&#xd558;&#xac8c; &#xb6f0;&#xc5b4;&#xb180; &#xc218; &#xc788;&#xb3c4;&#xb85d; &#xc774;&#xc6c3;&#xacfc; &#xc815;&#xc744; &#xc313;&#xc744; &#xc218; &#xc788;&#xb294; &#xc0ac;&#xb78c; &#xc911;&#xc2ec;&#xc758; &#xcf8c;&#xc801;&#xd55c; &#xac70;&#xb9ac;&#xb97c; &#xc870;&#xc131;&#xd558;&#xb294; &#xc0ac;&#xc5c5; [&#xb124;&#xc774;&#xbc84; &#xc9c0;&#xc2dd;&#xbc31;&#xacfc;] &#xadf8;&#xb9b0; &#xd30c;&#xd0b9; &#xb9c8;&#xc744; &#xc0ac;&#xc5c5; [-&#x4e8b;&#x696d;] (&#xd55c;&#xad6d;&#xd5a5;&#xd1a0;&#xbb38;&#xd654;&#xc804;&#xc790;&#xb300;&#xc804;)  "/>
</node>
<node CREATED="1596453348051" ID="ID_1926307610" MODIFIED="1596453355861" TEXT="&#xcc28;&#xace0;&#xc9c0;&#xc99d;&#xba85;&#xc81c;">
<node CREATED="1596453440938" ID="ID_1539741882" MODIFIED="1596453442169" TEXT="&#xcc28;&#xace0;&#xc9c0; &#xc99d;&#xba85;&#xc81c;&#xb780; &#xc8fc;&#xcc28;&#xacf5;&#xac04;&#xc744; &#xd655;&#xbcf4;&#xd574;&#xc57c; &#xcc28;&#xb97c; &#xad6c;&#xc785;&#xd560; &#xc218; &#xc788;&#xac8c; &#xd558;&#xb294; &#xc81c;&#xb3c4;&#xb85c;, &#xc790;&#xb3d9;&#xcc28;&#xc758; &#xc2e0;&#xaddc;&#x318d;&#xbcc0;&#xacbd;&#x318d;&#xc774;&#xc804;&#xb4f1;&#xb85d; &#xb54c; &#xcc28;&#xace0;&#xc9c0; &#xd655;&#xbcf4; &#xc99d;&#xbe59;&#xc11c;&#xb958; &#xc81c;&#xcd9c;&#xc744; &#xc758;&#xbb34;&#xd654;&#xd558;&#xb294; &#xac83;"/>
</node>
<node CREATED="1596453365337" ID="ID_841581365" MODIFIED="1596453367872" TEXT="&#xc8fc;&#xcc28; &#xacf5;&#xc720;&#xc81c;">
<node CREATED="1596453406278" ID="ID_1205564351" MODIFIED="1596453407820" TEXT="&#xb2e4;&#xb978; &#xc0ac;&#xb78c;&#xc5d0;&#xac8c; &#xc8fc;&#xcc28;&#xacf5;&#xac04;&#xc744; &#xbe4c;&#xb824;&#xc90c;&#xc73c;&#xb85c;&#xc368; &#xc8fc;&#xcc28; &#xd06c;&#xb808;&#xb527;(Parking credit) &#xb610;&#xb294; &#xc77c;&#xc815; &#xc694;&#xae08;&#xc744; &#xbc1b;&#xc744; &#xc218;&#xb3c4; &#xc788;&#xc73c;&#xba70;, &#xd06c;&#xb808;&#xb527;&#xc744; &#xc774;&#xc6a9;&#xd558;&#xc5ec; &#xb2e4;&#xb978; &#xacf5;&#xacf5;&#xc8fc;&#xcc28;&#xc7a5;&#xc744; &#xbb34;&#xb8cc;&#xb85c; &#xc774;&#xc6a9;&#xd560; &#xc218; &#xc788;&#xb294; &#xc7a5;&#xc810;"/>
</node>
</node>
<node CREATED="1596450628163" ID="ID_1032717764" MODIFIED="1596450629143" TEXT="&#xc6d0;&#xc778;">
<node CREATED="1596451614376" ID="ID_952600279" MODIFIED="1596451618648" TEXT="&#xc8fc;&#xcc28;&#xc2dc;&#xc124;&#xc758; &#xbd80;&#xc871;">
<node CREATED="1596451778271" ID="ID_754779138" MODIFIED="1596451831475">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      960&#47749; &#54364;&#48376;&#51004;&#47196; &#48520;&#48277;&#51452;&#51221;&#52264;&#47484; &#54616;&#45716; &#51060;&#50976; &#51312;&#49324;
    </p>
    <p>
      &#51452;&#52264; &#49884;&#49444;&#51032; &#48512;&#51313;: 52.2%
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1596452112842" ID="ID_187421571" MODIFIED="1596452201931">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#48520;&#48277; &#51452;&#51221;&#52264; &#44221;&#54744; 777&#47749; &#45824;&#49345; &#51312;&#49324;
    </p>
    <p>
      &#51452;&#48320;&#50640; &#51452;&#52264;&#54624; &#44275;&#51060; &#50630;&#50612;&#49436; 69.2%
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1596451619038" ID="ID_1587898979" MODIFIED="1596451632244" TEXT="&#xc8fc;&#xcc28;&#xc2dc;&#xc124;&#xc758; &#xc811;&#xadfc;&#xc131; &#xb0ae;&#xc74c;">
<node CREATED="1596452127729" ID="ID_1698359540" MODIFIED="1596452167202">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#48520;&#48277; &#51452;&#51221;&#52264; &#44221;&#54744; 777&#47749; &#45824;&#49345; &#51312;&#49324;
    </p>
    <p>
      &#51452;&#48320;&#50640; &#47560;&#46405;&#55176; &#51452;&#52264;&#54624; &#44275;&#51060; &#50630;&#50612;&#49436; 68.9%
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node CREATED="1596441227465" ID="ID_1753766261" MODIFIED="1596448439620" POSITION="right" TEXT="&#xbc30;&#xae30; &#xac00;&#xc2a4;&#xb7c9; &#xc99d;&#xac00;">
<node CREATED="1596441261316" ID="ID_84110268" MODIFIED="1596443426344" TEXT="&#xc815;&#xc758;">
<node CREATED="1596442898479" ID="ID_1971365482" MODIFIED="1596443420238" TEXT="&apos;&#xbc30;&#xae30; &#xac00;&#xc2a4;&apos; &#xb780;?">
<node CREATED="1596443087560" ID="ID_226314359" MODIFIED="1596443318431" TEXT="&#xbc30;&#xae30;">
<node CREATED="1596443281636" ID="ID_669320776" MODIFIED="1596443466165" TEXT="&#xb0b4;&#xc5f0;&#xae30;&#xad00; &#xb4f1;&#xc5d0;&#xc11c; &#xc5f0;&#xb8cc;&#xb97c; &#xc0ac;&#xc6a9;&#xd55c; &#xd6c4; &#xae30;&#xccb4;&#xb97c; &#xbc16;&#xc73c;&#xb85c; &#xb0b4;&#xbcf4;&#xb0b4;&#xb294; &#xc77c;.(&#xcd9c;&#xcc98; : &#xb450;&#xc0b0;&#xbc31;&#xacfc;)"/>
</node>
<node CREATED="1596443090859" ID="ID_1997646039" MODIFIED="1596443335761" TEXT="&#xac00;&#xc2a4;">
<node CREATED="1596443322639" ID="ID_1033663852" MODIFIED="1596443476920" TEXT="&#xc77c;&#xbc18;&#xc801;&#xc73c;&#xb85c;&#xb294; &#xae30;&#xccb4; &#xc0c1;&#xd0dc;&#xb85c; &#xc788;&#xb294; &#xd1b5;&#xd2c0;&#xc5b4; &#xc774;&#xb974;&#xb294; &#xb9d0;&#xc774;&#xc9c0;&#xb9cc; &#xc5f0;&#xb8cc;&#xb85c; &#xc0ac;&#xc6a9;&#xb418;&#xb294; &#xae30;&#xccb4;&#xb97c; &#xac00;&#xb9ac;&#xd0a8;&#xb2e4;.(&#xcd9c;&#xcc98; : &#xb450;&#xc0b0;&#xbc31;&#xacfc;)"/>
</node>
<node CREATED="1596444900485" ID="ID_222358241" MODIFIED="1596444937748" TEXT="&#xb9e4;&#xc5f0;&#xacfc;&#xc758; &#xcc28;&#xc774;">
<node CREATED="1596444938763" ID="ID_1781415677" MODIFIED="1596444975301" TEXT="&#xbc30;&#xae30;&#xac00;&#xc2a4;">
<node CREATED="1596444981139" ID="ID_463179880" MODIFIED="1596444981899" TEXT="&#xcc9c;&#xc5f0;&#xac00;&#xc2a4;&#xb098; &#xc11d;&#xc720;, &#xc11d;&#xd0c4;&#xacfc; &#xac19;&#xc740; &#xc5f0;&#xb85c;&#xc758; &#xc5f0;&#xc18c;&#xb85c; &#xbc1c;&#xc0dd;&#xb418;&#xb294; &#xac00;&#xc2a4;"/>
<node CREATED="1596444983505" ID="ID_431216247" MODIFIED="1596444992027" TEXT="&#xb300;&#xd45c;&#xc801;&#xc73c;&#xb85c; &#xc9c8;&#xc18c;&#xc640; &#xc218;&#xc99d;&#xae30;, &#xc774;&#xc0b0;&#xd654;&#xd0c4;&#xc18c;&#xac00; &#xc788;&#xb2e4;."/>
</node>
<node CREATED="1596444971630" ID="ID_91210371" MODIFIED="1596445059706" TEXT="&#xb9e4;&#xc5f0;">
<node CREATED="1596445006387" ID="ID_1613026470" MODIFIED="1596445033804" TEXT="&#xac01;&#xc885; &#xc5f0;&#xb8cc;&#xb97c; &#xc5f0;&#xc18c;&#xc2dc;&#xd0a4;&#xac70;&#xb098; &#xc6d0;&#xc790;&#xc7ac;&#xb97c; &#xc5f4;&#xcc98;&#xb9ac;&#xd558;&#xb294; &#xacfc;&#xc815;&#xc5d0;&#xc11c; &#xbc1c;&#xc0dd;&#xd558;&#xb294; &#xace0;&#xccb4;&#xb7;&#xae30;&#xccb4;&#xb7;&#xd718;&#xbc1c;&#xc131; &#xc99d;&#xae30; &#xb4f1;&#xacfc; &#xac19;&#xc774; &#xc8fc;&#xb85c; &#xb208;&#xc5d0; &#xbcf4;&#xc774;&#xb294; &#xc5f0;&#xae30;&#xc758; &#xc131;&#xbd84;.(&#xcd9c;&#xcc98; : &#xb450;&#xc0b0;&#xbc31;&#xacfc;)"/>
</node>
</node>
<node CREATED="1596445062560" ID="ID_1862053342" MODIFIED="1596445140392" TEXT="&#xbc30;&#xae30;&#xac00;&#xc2a4;&#xc758; &#xc885;&#xb958;&#xc640; &#xbe44;&#xc728;&#xc740; &#xc790;&#xb3d9;&#xcc28;&#xc758; &#xc885;&#xb958;&#xc5d0; &#xb530;&#xb77c; &#xb2e4;&#xb984;">
<node CREATED="1596445143840" ID="ID_1407065476" MODIFIED="1596445149749" TEXT="&#xd718;&#xbc1c;&#xc720;(&#xac00;&#xc194;&#xb9b0;) &#xcc28;&#xb7c9;">
<node CREATED="1596445212061" ID="ID_817070774" MODIFIED="1596445310674" TEXT="&#xd718;&#xbc1c;&#xc720;">
<node CREATED="1596445314045" ID="ID_1559608550" MODIFIED="1596445331248" TEXT="&#xc11d;&#xc720;&#xc758; &#xd718;&#xbc1c; &#xc131;&#xbd84;&#xc744; &#xc774;&#xb8e8;&#xb294; &#xbb34;&#xc0c9;&#xc758; &#xd22c;&#xba85;&#xd55c; &#xc561;&#xccb4;.(&#xcd9c;&#xcc98; : &#xd45c;&#xc900;&#xad6d;&#xc5b4;&#xb300;&#xc0ac;&#xc804;)"/>
<node CREATED="1596445316237" ID="ID_747927711" MODIFIED="1596445346413" TEXT="&#xc6d0;&#xc720;&#xc5d0;&#xc11c; &#xbd88;&#xb9ac;&#xb41c; &#xbb3c;&#xc9c8; &#xc911; &#xc57d; 30~200&apos;c&#xc758; &#xb053;&#xb294;&#xc810; &#xbc94;&#xc704;&#xb97c; &#xac16;&#xb294; &#xd63c;&#xd569;&#xbb3c; "/>
</node>
</node>
<node CREATED="1596445399907" ID="ID_99995932" MODIFIED="1596445484849" TEXT="&#xacbd;&#xc6b0;(&#xb514;&#xc824;) &#xcc28;&#xb7c9;">
<node CREATED="1596445488709" ID="ID_1986738139" MODIFIED="1596445515491" TEXT="&#xacbd;&#xc720;">
<node CREATED="1596445492677" ID="ID_1799141088" MODIFIED="1596445499136" TEXT="&#xb053;&#xb294;&#xc810;&#xc774; 250~350&apos;c &#xc0ac;&#xc774;&#xc5d0; &#xc788;&#xb294; &#xd0c4;&#xd654;&#xc218;&#xc18c;&#xb4e4;&#xc758; &#xd63c;&#xd569;&#xbb3c;&#xb85c;&#xc11c; &#xc99d;&#xb958;&#xd0d1;&#xc5d0;&#xc11c; &#xb4f1;&#xc720; &#xb2e4;&#xc74c;&#xc73c;&#xb85c; &#xc720;&#xcd9c;&#xb418;&#xb294; &#xc11d;&#xc720; "/>
<node CREATED="1596445501664" ID="ID_1052098861" MODIFIED="1596445509814" TEXT="&#xc911;&#xc720;&#xc5d0; &#xbe44;&#xd574; &#xbc00;&#xb3c4;&#xac00; &#xb0ae;&#xae30; &#xb54c;&#xbb38;&#xc5d0; &#xd55c;&#xc790; &apos;&#xac00;&#xbcbc;&#xc6b8; &#xacbd;&apos;&#xc744; &#xc368;&#xc11c; &#xacbd;&#xc720;"/>
<node CREATED="1596445521767" ID="ID_1349048563" MODIFIED="1596445531714" TEXT="&#xc601;&#xc5b4;&#xb85c; &#xb514;&#xc824;&#xc720;(diesel fuel)&#xc774;&#xb77c;&#xace0; &#xd558;&#xb294;&#xb370; &#xb514;&#xc824; &#xc5d4;&#xc9c4;&#xc758; &#xc5f0;&#xb8cc;&#xb85c; &#xb9ce;&#xc774; &#xc0ac;&#xc6a9;&#xd558;&#xae30; &#xb54c;&#xbb38;"/>
</node>
</node>
</node>
</node>
<node CREATED="1596443340097" ID="ID_1593547509" MODIFIED="1596443403745" TEXT="&#xc5d4;&#xc9c4;&#xc758; &#xbc30;&#xae30;&#xad00;&#xc5d0;&#xc11c; &#xc678;&#xbd80;&#xb85c; &#xbc30;&#xcd9c;&#xb418;&#xb294; &#xac00;&#xc2a4;&#xb97c; &#xb9d0;&#xd568;.(&#xcd9c;&#xcc98; : &#xc790;&#xb3d9;&#xcc28; &#xc6a9;&#xc5b4;&#xc0ac;&#xc804;)"/>
</node>
<node CREATED="1596441264210" ID="ID_423588953" MODIFIED="1596444711742" TEXT="&#xd604;&#xd669;">
<node CREATED="1596443515728" ID="ID_1380334103" MODIFIED="1596443823216" TEXT="&#xc790;&#xb3d9;&#xcc28; &#xbc30;&#xcd9c;&#xac00;&#xc2a4; &#xbc30;&#xcd9c;&#xd5c8;&#xc6a9; &#xae30;&#xc900;">
<node CREATED="1596443825003" FOLDED="true" ID="ID_1250982241" MODIFIED="1596445462487" TEXT="1. &#xacbd;&#xc720; &#xc790;&#xb3d9;&#xcc28; &#xbc30;&#xcd9c;&#xac00;&#xc2a4; &#xae30;&#xc900; (&#xb300;&#xae30;&#xd658;&#xacbd;&#xbcf4;&#xc804;&#xbc95; &#xc2dc;&#xd589;&#xaddc;&#xce59; &#xc81c;78&#xc870; [&#xbcc4;&#xd45c;21] )">
<node CREATED="1596443902311" ID="ID_118683905" MODIFIED="1596443921083" TEXT="&#xacbd;&#xc790;&#xb3d9;&#xcc28;&#xbc0f;&#xc2b9;&#xc6a9;&#xc790;&#xb3d9;&#xcc28;&#x9;">
<node CREATED="1596443994129" ID="ID_1565726935" MODIFIED="1596443998195" TEXT="2004&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2007&#xb144; 12&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444001258" ID="ID_1402787251" MODIFIED="1596444003120" TEXT="40% &#xc774;&#xd558;"/>
</node>
<node CREATED="1596444006850" ID="ID_893199733" MODIFIED="1596444010550" TEXT="2008&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2016&#xb144; 8&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444011428" ID="ID_1701041810" MODIFIED="1596444013658" TEXT="20%&#xc774;&#xd558;"/>
</node>
<node CREATED="1596444016097" ID="ID_1605349804" MODIFIED="1596444019205" TEXT="2016&#xb144; 9&#xc6d4; 1&#xc77c; &#xc774;&#xd6c4;&#x9;">
<node CREATED="1596444020524" ID="ID_1046985450" MODIFIED="1596444024005" TEXT="10%&#xc774;&#xd558; "/>
</node>
</node>
<node CREATED="1596443936670" ID="ID_1867085961" MODIFIED="1596444126140" TEXT="&#xc2b9;&#xd569;&#xb7;&#xd654;&#xbb3c;&#xb7;&#xd2b9;&#xc218;&#xc790;&#xb3d9;&#xcc28;&#x9;">
<node CREATED="1596443938558" ID="ID_1995501691" MODIFIED="1596443943111" TEXT="&#xc18c;&#xd615;">
<node CREATED="1596444030975" ID="ID_1150939277" MODIFIED="1596444032104" TEXT="2004&#xb144; 1&#xc6d4; 1&#xc77c;1&#xbd80;&#xd130; 2007&#xb144; 12&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444033149" ID="ID_1083187" MODIFIED="1596444037224" TEXT="40%&#xc774;&#xd558; "/>
</node>
<node CREATED="1596444041749" ID="ID_584996892" MODIFIED="1596444046145" TEXT="2008&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2016&#xb144; 8&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444046988" ID="ID_1348188048" MODIFIED="1596444050381" TEXT="20%&#xc774;&#xd558; "/>
</node>
<node CREATED="1596444052876" ID="ID_191041826" MODIFIED="1596444055862" TEXT="2016&#xb144; 9&#xc6d4; 1&#xc77c; &#xc774;&#xd6c4;&#x9;">
<node CREATED="1596444056608" ID="ID_1925594376" MODIFIED="1596444059878" TEXT="10%&#xc774;&#xd558; "/>
</node>
</node>
<node CREATED="1596444127133" ID="ID_765002405" MODIFIED="1596444129093" TEXT="&#xc911;&#xd615; &#xb300;&#xd615;">
<node CREATED="1596444130069" ID="ID_312594090" MODIFIED="1596444134095" TEXT="1998&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2000&#xb144; 12&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444135052" ID="ID_549234294" MODIFIED="1596444136650" TEXT="&#xc2dc;&#xb0b4;&#xbc84;&#xc2a4;">
<node CREATED="1596444138785" ID="ID_1336206744" MODIFIED="1596444143989" TEXT="40% &#xc774;&#xd558;"/>
</node>
<node CREATED="1596444146294" ID="ID_1594501919" MODIFIED="1596444148392" TEXT="&#xc2dc;&#xb0b4;&#xbc84;&#xc2a4;&#xc678;">
<node CREATED="1596444153095" ID="ID_1627914616" MODIFIED="1596444156215" TEXT="45%&#xc774;&#xd558;"/>
</node>
</node>
<node CREATED="1596444159453" ID="ID_1373789412" MODIFIED="1596444164139" TEXT="2001&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2004&#xb144; 9&#xc6d4; 30&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444168963" ID="ID_1886470209" MODIFIED="1596444169909" TEXT="45%&#xc774;&#xd558; "/>
</node>
<node CREATED="1596444173453" ID="ID_1741467648" MODIFIED="1596444176249" TEXT="2004&#xb144; 10&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2007&#xb144; 12&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444177385" ID="ID_1432673698" MODIFIED="1596444180121" TEXT="40%&#xc774;&#xd558; "/>
</node>
<node CREATED="1596444183199" ID="ID_846688370" MODIFIED="1596444186397" TEXT="2008&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2016&#xb144; 8&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444187973" ID="ID_1479665269" MODIFIED="1596444191058" TEXT="20%&#xc774;&#xd558; "/>
</node>
<node CREATED="1596444194639" ID="ID_1389090487" MODIFIED="1596444197424" TEXT="2016&#xb144; 9&#xc6d4; 1&#xc77c; &#xc774;&#xd6c4;&#x9;">
<node CREATED="1596444199493" ID="ID_1827953839" MODIFIED="1596444202943" TEXT="10%&#xc774;&#xd558;"/>
</node>
</node>
</node>
</node>
<node CREATED="1596443837711" FOLDED="true" ID="ID_713490229" MODIFIED="1596448294113" TEXT="2. &#xd718;&#xbc1c;&#xc720;&#xb7;&#xac00;&#xc2a4; &#xc790;&#xb3d9;&#xcc28; &#xbc30;&#xcd9c;&#xac00;&#xc2a4; &#xae30;&#xc900;&#xd45c; (&#xb300;&#xae30;&#xd658;&#xacbd;&#xbcf4;&#xc804;&#xbc95; &#xc2dc;&#xd589;&#xaddc;&#xce59; &#xc81c;78&#xc870; [&#xbcc4;&#xd45c;21] )">
<node CREATED="1596444220281" ID="ID_1633253005" MODIFIED="1596444288405" TEXT="1. &#xacbd;&#xc790;&#xb3d9;&#xcc28;&#x9;">
<node CREATED="1596444242244" ID="ID_919484748" MODIFIED="1596444255553" TEXT="1997&#xb144; 12&#xc6d4; 31&#xc77c; &#xc774;&#xc804;&#x9;">
<node CREATED="1596444256724" ID="ID_1854556879" MODIFIED="1596444261886" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 4.5%&#xc774;&#xd558;"/>
<node CREATED="1596444263219" ID="ID_913800045" MODIFIED="1596444282249" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 1,200ppm &#xc774;&#xd558;&#x9;"/>
</node>
<node CREATED="1596444289600" ID="ID_1153396544" MODIFIED="1596444292654" TEXT="1998&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2000&#xb144; 12&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444293630" ID="ID_1742788806" MODIFIED="1596444301933" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c;2.5%&#xc774;&#xd558;"/>
<node CREATED="1596444303154" ID="ID_1324713365" MODIFIED="1596444310463" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c;400ppm&#xc774;&#xd558;"/>
</node>
<node CREATED="1596444314221" ID="ID_1779471045" MODIFIED="1596444316971" TEXT="2001&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2003&#xb144; 12&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444318455" ID="ID_1479962764" MODIFIED="1596444323283" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 1.2%&#xc774;&#xd558;"/>
<node CREATED="1596444324335" ID="ID_994978278" MODIFIED="1596444331031" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 220ppm&#xc774;&#xd558;"/>
</node>
<node CREATED="1596444336349" ID="ID_990719449" MODIFIED="1596444340281" TEXT="2004&#xb144; 1&#xc6d4; 1&#xc77c; &#xc774;&#xd6c4;&#x9;">
<node CREATED="1596444341526" ID="ID_216359186" MODIFIED="1596444345639" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 1.0%&#xc774;&#xd558;"/>
<node CREATED="1596444347750" ID="ID_875253132" MODIFIED="1596444353626" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 150ppm&#xc774;&#xd558;"/>
</node>
</node>
<node CREATED="1596444229849" ID="ID_181745492" MODIFIED="1596444232343" TEXT="2. &#xc2b9;&#xc6a9;&#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596444366270" ID="ID_758770262" MODIFIED="1596444394706" TEXT="1987&#xb144; 12&#xc6d4; 31&#xc77c; &#xc774;&#xc804;&#x9;">
<node CREATED="1596444370143" ID="ID_1612458021" MODIFIED="1596444372919" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 4.5%&#xc774;&#xd558;&#x9;"/>
<node CREATED="1596444374475" ID="ID_32542598" MODIFIED="1596444380409" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 1,200ppm &#xc774;&#xd558; "/>
</node>
<node CREATED="1596444386415" ID="ID_1485670245" MODIFIED="1596444387280" TEXT="1988&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2000&#xb144; 12&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444396674" ID="ID_392883943" MODIFIED="1596444400827" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 1.2%&#xc774;&#xd558;&#x9;"/>
<node CREATED="1596444403132" ID="ID_977674176" MODIFIED="1596444408036" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 220ppm&#xc774;&#xd558;(&#xd718;&#xbc1c;&#xc720;&#xb7;&#xc54c;&#xcf5c;&#xc0ac;&#xc6a9;&#xc790;&#xb3d9;&#xcc28;) 400ppm&#xc774;&#xd558;(&#xac00;&#xc2a4;&#xc0ac;&#xc6a9; &#xc790;&#xb3d9;&#xcc28;) "/>
</node>
<node CREATED="1596444411026" ID="ID_470622926" MODIFIED="1596444414347" TEXT="2001&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2005&#xb144; 12&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;&#x9;">
<node CREATED="1596444415899" ID="ID_525941875" MODIFIED="1596444420838" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 1.2%&#xc774;&#xd558;&#x9;"/>
<node CREATED="1596444422069" ID="ID_563902778" MODIFIED="1596444427487" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 220ppm&#xc774;&#xd558; "/>
</node>
<node CREATED="1596444430362" ID="ID_711714344" MODIFIED="1596444435202" TEXT="2006&#xb144; 1&#xc6d4; 1&#xc77c; &#xc774;&#xd6c4;&#x9;">
<node CREATED="1596444436224" HGAP="24" ID="ID_1376752068" MODIFIED="1596444451420" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 1.0%&#xc774;&#xd558;"/>
<node CREATED="1596444452601" ID="ID_264428451" MODIFIED="1596444460345" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 120ppm&#xc774;&#xd558; "/>
</node>
</node>
<node CREATED="1596444233687" ID="ID_1498548134" MODIFIED="1596444240581" TEXT="3. &#xd654;&#xbb3c;, &#xd2b9;&#xc218;&#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596444469475" ID="ID_516463643" MODIFIED="1596444470864" TEXT="&#xc18c;&#xd615;">
<node CREATED="1596444471810" ID="ID_1488310554" MODIFIED="1596444485305" TEXT="1989&#xb144; 12&#xc6d4; 31&#xc77c; &#xc774;&#xc804;&#x9;">
<node CREATED="1596444475587" ID="ID_1410274892" MODIFIED="1596444481127" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 4.5%&#xc774;&#xd558;"/>
<node CREATED="1596444486541" ID="ID_886929100" MODIFIED="1596444488220" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 1,200ppm &#xc774;&#xd558; "/>
</node>
<node CREATED="1596444491262" ID="ID_237241674" MODIFIED="1596444494276" TEXT="1990&#xb144; 1&#xc6d4; 1&#xc77c;&#xbd80;&#xd130; 2003&#xb144; 12&#xc6d4; 31&#xc77c;&#xae4c;&#xc9c0;">
<node CREATED="1596444548141" ID="ID_1870830156" MODIFIED="1596444550114" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 2.5%&#xc774;&#xd558;&#x9;"/>
<node CREATED="1596444551351" ID="ID_1236687611" MODIFIED="1596444558773" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 400 ppm&#xc774;&#xd558;"/>
</node>
<node CREATED="1596444562072" ID="ID_928605222" MODIFIED="1596444564897" TEXT="2004&#xb144; 1&#xc6d4; 1&#xc77c; &#xc774;&#xd6c4;&#x9;">
<node CREATED="1596444566902" ID="ID_1158191858" MODIFIED="1596444569914" TEXT="1.2%&#xc774;&#xd558;&#x9;"/>
<node CREATED="1596444571127" ID="ID_776847232" MODIFIED="1596444574009" TEXT="220ppm&#xc774;&#xd558; "/>
</node>
</node>
<node CREATED="1596444577104" ID="ID_1832761637" MODIFIED="1596444579995" TEXT="&#xc911;&#xd615;&#xb7;&#xb300;&#xd615;&#x9;">
<node CREATED="1596444581313" ID="ID_133099089" MODIFIED="1596444584896" TEXT="2003&#xb144; 12&#xc6d4; 31&#xc77c; &#xc774;&#xc804;&#x9;">
<node CREATED="1596444588968" ID="ID_281398968" MODIFIED="1596444594728" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 4.5%&#xc774;&#xd558;&#x9;"/>
<node CREATED="1596444595896" ID="ID_450744271" MODIFIED="1596444604064" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 1,200ppm &#xc774;&#xd558; "/>
</node>
<node CREATED="1596444585932" ID="ID_1911208591" MODIFIED="1596444588191" TEXT="2004&#xb144; 1&#xc6d4; 1&#xc77c; &#xc774;&#xd6c4;&#x9;">
<node CREATED="1596444605000" ID="ID_1715212446" MODIFIED="1596444611965" TEXT="&#xc77c;&#xc0b0;&#xd654;&#xd0c4;&#xc18c; 2.5%&#xc774;&#xd558;&#x9;"/>
<node CREATED="1596444613021" ID="ID_1733171354" MODIFIED="1596444626860" TEXT="&#xd0c4;&#xd654;&#xc218;&#xc18c; 400ppm&#xc774;&#xd558; "/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1596444712805" ID="ID_904671362" MODIFIED="1596448086329" TEXT="&#xbb38;&#xc81c;">
<node CREATED="1596444886595" ID="ID_1158867290" MODIFIED="1596448053472" TEXT="&#xacbd;&#xc720;&#xcc28;&#xc5d0;&#xc11c; &#xbc30;&#xcd9c;&#xd558;&#xb294; &#xbc30;&#xae30;&#xac00;&#xc2a4;&#xc5d0;&#xb294; 1&#xae09; &#xbc1c;&#xc554;&#xbb3c;&#xc9c8;&#xc774; &#xb2e4;&#xb7c9; &#xd568;&#xc720; &#xb3fc; &#xc788;&#xb2e4;  (&#xcd9c;&#xcc98; : &#xc624;&#xd1a0;&#xd5e4;&#xb7f4;&#xb4dc;)"/>
<node CREATED="1596448096946" ID="ID_1303006635" MODIFIED="1596448117406" TEXT="&#xbc30;&#xae30;&#xac00;&#xc2a4;&#xb294; &#xb1cc;&#xc878;&#xc911; &#xb1cc;&#xacbd;&#xc0c9;&#xacfc; &#xc2ec;&#xd608;&#xad00; &#xacc4;&#xd1b5; &#xc9c8;&#xd658;&#xc758; &#xc6d0;&#xc778;&#xc774; &#xb428;"/>
</node>
</node>
<node CREATED="1596441270619" ID="ID_1313985784" MODIFIED="1596443729441" TEXT="&#xb300;&#xcc45;">
<node CREATED="1596443546317" ID="ID_125904957" MODIFIED="1596443674335" TEXT="&#xbc30;&#xcd9c;&#xac00;&#xc2a4;&#xc800;&#xac10;&#xc0ac;&#xc5c5;">
<node CREATED="1596443559474" ID="ID_522051621" MODIFIED="1596443592447" TEXT="&#xc800;&#xac10; : [&#xba85;&#xc0ac;] &#xb0ae;&#xcd94;&#xc5b4; &#xc904;&#xc784; (&#xcd9c;&#xcc98; : &#xd45c;&#xc900;&#xad6d;&#xc5b4;&#xb300;&#xc0ac;&#xc804;)"/>
<node CREATED="1596443600645" ID="ID_132849376" MODIFIED="1596443656882" TEXT="2005.1.1&#xbd80;&#xd130; &#xb300;&#xae30;&#xad00;&#xb9ac;&#xad8c;&#xc5ed;&#xc5d0; &#xb4f1;&#xb85d;&#xb418;&#xc5b4;&#xc788;&#xb294; &#xd2b9;&#xc815;&#xacbd;&#xc720;&#xc790;&#xb3d9;&#xcc28;(&#xbc30;&#xcd9c;&#xac00;&#xc2a4; &#xbcf4;&#xc99d;&#xae30;&#xac04;&#xc774; &#xc9c0;&#xb09c; &#xacbd;&#xc720;&#xc790;&#xb3d9;&#xcc28;)&#xc5d0; &#xb300;&#xd558;&#xc5ec;&#xb294; &#xb300;&#xae30;&#xd658;&#xacbd;&#xbcf4;&#xc804;&#xbc95;&#xc758; &#xc6b4;&#xd589;&#xc790;&#xb3d9;&#xcc28; &#xbc30;&#xcd9c;&#xd5c8;&#xc6a9;&#xae30;&#xc900;&#xbcf4;&#xb2e4; &#xac15;&#xd654;&#xb41c; &#xd2b9;&#xc815;&#xacbd;&#xc720;&#xc790;&#xb3d9;&#xcc28; &#xbc30;&#xcd9c;&#xd5c8;&#xc6a9;&#xae30;&#xc900;&#xc5d0; &#xb530;&#xb77c; &#xad00;&#xb9ac;&#xb429;&#xb2c8;&#xb2e4;.&#xa;&#xa;&#x300e;&#xc218;&#xb3c4;&#xad8c;&#xb300;&#xae30;&#xd658;&#xacbd;&#xac1c;&#xc120;&#xc5d0; &#xad00;&#xd55c; &#xd2b9;&#xbcc4;&#xbc95;&#x300f;"/>
<node CREATED="1596443639050" ID="ID_1088629395" MODIFIED="1596443692765" TEXT=" &#xd2b9;&#xc815;&#xacbd;&#xc720;&#xc790;&#xb3d9;&#xcc28; &#xc18c;&#xc720;&#xc790;&#xb294; &#xd2b9;&#xc815;&#xacbd;&#xc720;&#xc790;&#xb3d9;&#xcc28; &#xbc30;&#xcd9c;&#xd5c8;&#xc6a9;&#xae30;&#xc900;&#xc5d0; &#xc801;&#xd569;&#xd558;&#xac8c; &#xc720;&#xc9c0;&#xd560; &#xc218; &#xc788;&#xb3c4;&#xb85d; &#xc544;&#xb798;&#xc640; &#xac19;&#xc774; &#xc870;&#xce58;&#xb97c; &#xd574;&#xc57c; &#xd558;&#xba70;, &#xc774;&#xb54c; &#xc18c;&#xc694;&#xb418;&#xb294; &#xacbd;&#xbe44;&#xc758; &#xc77c;&#xbd80;&#xb97c; &#xc815;&#xbd80;&#xc5d0;&#xc11c; &#xbcf4;&#xc870;&#xd574; &#xc8fc;&#xb294; &#xc0ac;&#xc5c5;&#xc744; &#xb9d0;&#xd569;&#xb2c8;&#xb2e4;."/>
</node>
<node CREATED="1596443730525" ID="ID_317018170" MODIFIED="1596443732601" TEXT="&#xce5c;&#xd658;&#xacbd; &#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596443739260" ID="ID_469299529" MODIFIED="1596448162145" TEXT="&#xc218;&#xc18c; &#xc790;&#xb3d9;&#xcc28;">
<node CREATED="1596448153977" ID="ID_805857889" MODIFIED="1596448157899" TEXT="&#xad50;&#xd1b5; &#xac00;&#xc194;&#xb9b0;&#xc774;&#xb098; &#xd504;&#xb85c;&#xd310;&#xac00;&#xc2a4; &#xb300;&#xc2e0; &#xc218;&#xc18c;&#xb97c; &#xc5f0;&#xb8cc;&#xb85c; &#xc4f0;&#xb294; &#xc790;&#xb3d9;&#xcc28;"/>
<node CREATED="1596448163166" ID="ID_1979489566" MODIFIED="1596448204502" TEXT="&#xc77c;&#xc0b0;&#xd654; &#xd0c4;&#xc18c;, &#xd0c4;&#xd654;&#xc218;&#xc18c;, &#xc9c8;&#xc18c; &#xc0b0;&#xd654;&#xbb3c; &#xb530;&#xc704;&#xac00; &#xc801;&#xac8c; &#xbc30;&#xcd9c;&#xb41c;&#xb2e4;.(&#xcd9c;&#xcc98; : &#xc6b0;&#xb9ac;&#xb9d0;&#xc0d8;)"/>
</node>
<node CREATED="1596443736268" ID="ID_1614601926" MODIFIED="1596443737823" TEXT="&#xc804;&#xae30;&#xcc28;">
<node CREATED="1596448226347" ID="ID_1611982386" MODIFIED="1596448255745" TEXT="&#xc9c1;&#xb958; &#xc804;&#xb3d9;&#xae30;(&#x76f4;&#x6d41;&#x96fb;&#x52d5;&#x6a5f;)&#xb97c; &#xc6d0;&#xb3d9;&#xae30;&#xb85c; &#xd558;&#xace0; &#xcd95;&#xc804;&#xc9c0;&#xb97c; &#xc804;&#xc6d0;&#xc73c;&#xb85c; &#xc0ac;&#xc6a9;&#xd558;&#xb294; &#xc790;&#xb3d9;&#xcc28;(&#xcd9c;&#xcc98; : &#xace0;&#xb824;&#xb300; &#xd55c;&#xad6d;&#xc5b4;&#xb300;&#xc0ac;&#xc804;)"/>
<node CREATED="1596448234844" ID="ID_39649895" MODIFIED="1596448242692" TEXT="&#xbc30;&#xae30;&#xac00;&#xc2a4;&#xac00; &#xc5c6;&#xace0; &#xc18c;&#xc74c;&#xc774; &#xc544;&#xc8fc; &#xc791;&#xb2e4;&#xb294; &#xc7a5;&#xc810;&#xc774; &#xc788;&#xc73c;&#xb098;, &#xcd95;&#xc804;&#xc9c0;&#xac00; &#xd06c;&#xace0; &#xbb34;&#xac70;&#xc6b0;&#xba70; &#xc624;&#xb798; &#xb2ec;&#xb9b4; &#xc218; &#xc5c6;&#xb2e4;&#xb294; &#xb2e8;&#xc810;&#xc774; &#xc788;&#xb2e4;."/>
</node>
</node>
</node>
</node>
<node CREATED="1596448416240" ID="ID_740912273" MODIFIED="1596454244463" POSITION="right" TEXT="&#xc18c;&#xc74c;&#xacf5;&#xd574;">
<node CREATED="1596448487155" ID="ID_1088585738" MODIFIED="1596448493273" TEXT="&#xc815;&#xc758;">
<node CREATED="1596448531511" ID="ID_1882604186" MODIFIED="1596448817111" TEXT="&#xc18c;&#xc74c;">
<node CREATED="1596448821130" ID="ID_1581313864" MODIFIED="1596448846879" TEXT="&#xb2e8;&#xc704; : &#xb370;&#xc2dc;&#xbca8;&#xc5d0;&#xc774;[dB(A)]"/>
<node CREATED="1596448848928" ID="ID_1313106334" MODIFIED="1596448862910" TEXT="&#xc0ac;&#xb78c;&#xc774; &#xc815;&#xc0c1;&#xc801;&#xc778; &#xadc0;&#xb85c; &#xb4e4;&#xc744; &#xc218; &#xc788;&#xb294; &#xac00;&#xc7a5; &#xc791;&#xc740; &#xb2e8;&#xc704; &#xd06c;&#xae30;&#xc778; 0dB(A)&#xb85c;&#xbd80;&#xd130; 10dB(A)&#xc529; &#xc99d;&#xac00;&#xd560; &#xb54c;&#xb9c8;&#xb2e4; &#xc18c;&#xc74c;&#xc758; &#xac15;&#xb3c4;&#xac00; 10&#xbc30;&#xc529; &#xc99d;&#xac00;"/>
<node CREATED="1596448942581" ID="ID_1243157338" MODIFIED="1596449199983" TEXT="&#xb370;&#xc2dc;&#xbca8;dB(A)&#xc5d0; &#xb530;&#xb978; &#xc601;&#xd5a5; (&#xcd9c;&#xcc98; : &#xc138;&#xacc4;&#xbcf4;&#xac74;&#xae30;&#xad6c;)">
<node CREATED="1596449036080" ID="ID_632538082" MODIFIED="1596449093661" TEXT="40dB(A) &#xc774;&#xc0c1; : &#xc218;&#xba74;&#xc5d0; &#xc601;&#xd5a5;&#xc744; &#xbbf8;&#xce58;&#xae30; &#xc2dc;&#xc791;"/>
<node CREATED="1596449056950" ID="ID_1540032963" MODIFIED="1596449088624" TEXT="50dB(A) &#xc774;&#xc0c1;&#xbd80;&#xd130; &#xbd88;&#xcf8c;&#xac10;&#xc744; &#xd638;&#xc18c;"/>
<node CREATED="1596449104268" ID="ID_619463095" MODIFIED="1596449129512" TEXT="60dB(A) &#xc774;&#xc0c1; : &#xc2e0;&#xccb4;&#xc801; &#xac74;&#xac15;&#xc5d0;&#xb3c4; &#xc545;&#xc601;&#xd5a5;">
<node CREATED="1596449133752" ID="ID_470527953" MODIFIED="1596449161422" TEXT="80dB(A) &#xc774;&#xc0c1; : &#xccad;&#xb825; &#xc7a5;&#xc560; &#xc2dc;&#xc791;"/>
<node CREATED="1596449161752" ID="ID_419963701" MODIFIED="1596449176642" TEXT="90dB(A) &#xc774;&#xc0c1; : &#xc9c1;&#xc5c5;&#xc131; &#xb09c;&#xccad; &#xc2dc;&#xc791; , &#xc18c;&#xbcc0;&#xb7c9; &#xc99d;&#xac00;"/>
<node CREATED="1596449177324" ID="ID_1242527531" MODIFIED="1596449187753" TEXT="100dB(A) &#xc774;&#xc0c1; : &#xb2e8;&#xc2dc;&#xac04; &#xb178;&#xcd9c;&#xc2dc; &#xc77c;&#xc2dc;&#xc801; &#xb09c;&#xccad;"/>
</node>
<node CREATED="1596449231721" ID="ID_1225919159" MODIFIED="1596449271453" TEXT="&#xc138;&#xacc4;&#xbcf4;&#xac74;&#xae30;&#xad6c; &#xae30;&#xc900; &#xc8fc;&#xac70;&#xc9c0;&#xc5ed;&#xc758; &#xc625;&#xc678; &#xd658;&#xacbd;&#xc18c;&#xc74c; &#xac00;&#xc774;&#xb4dc;&#xb77c;&#xc778;&#xc740; 50dB(A)"/>
</node>
</node>
<node CREATED="1596448564063" ID="ID_1018074709" MODIFIED="1596448583795" TEXT="&#xacf5;&#xd574; : &#xc0b0;&#xc5c5;&#xc774;&#xb098; &#xad50;&#xd1b5;&#xc758; &#xbc1c;&#xb2ec;&#xc5d0; &#xb530;&#xb77c; &#xc0ac;&#xb78c;&#xc774;&#xb098; &#xc0dd;&#xbb3c;&#xc774; &#xc785;&#xac8c; &#xb418;&#xb294; &#xc5ec;&#xb7ec; &#xac00;&#xc9c0; &#xd53c;&#xd574;"/>
<node CREATED="1596448599776" ID="ID_601451897" MODIFIED="1596448612488" TEXT="&apos;&#xc18c;&#xc74c;&#xacf5;&#xd574;&apos; &#xb780; ?">
<node CREATED="1596448615330" ID="ID_901670188" MODIFIED="1596448621961" TEXT="&#xd658;&#xacbd; &#xbd88;&#xcf8c;&#xd558;&#xace0; &#xc2dc;&#xb044;&#xb7ec;&#xc6b4; &#xc18c;&#xb9ac; &#xb54c;&#xbb38;&#xc5d0; &#xc0ac;&#xb78c;&#xc774;&#xb098; &#xc0dd;&#xbb3c;&#xc774; &#xc785;&#xb294; &#xc5ec;&#xb7ec; &#xac00;&#xc9c0; &#xd53c;&#xd574;"/>
<node CREATED="1596448627395" ID="ID_1572727246" MODIFIED="1596448668833" TEXT="&#xc77c;&#xbc18;&#xc801;&#xc73c;&#xb85c; &#xd3c9;&#xac00; &#xc18c;&#xc74c;&#xc774; 50&#xb370;&#xc2dc;&#xbca8;(dB) &#xc774;&#xc0c1;&#xc774;&#xac70;&#xb098; &#xace0;&#xc8fc;&#xd30c; &#xc131;&#xbd84;&#xc774; 400(Hz) &#xc774;&#xc0c1;&#xc778; &#xacbd;&#xc6b0;&#xc774;&#xb2e4;. (&#xcd9c;&#xcc98; : &#xc6b0;&#xb9ac;&#xb9d0;&#xc0d8;)"/>
</node>
</node>
<node CREATED="1596448495033" ID="ID_1838287123" MODIFIED="1596448496221" TEXT="&#xd604;&#xd669;">
<node CREATED="1596449290121" ID="ID_679503245" MODIFIED="1596449924880" TEXT="&#xc18c;&#xc74c;&#xacf5;&#xd574;&#xc758; &#xc6d0;&#xc778; ">
<node CREATED="1596449295529" ID="ID_1261532438" MODIFIED="1596449629503" TEXT="&#xc0dd;&#xd65c;&#xc18c;&#xc74c;">
<node CREATED="1596449612392" ID="ID_310846319" MODIFIED="1596449615958" TEXT="&#xc0dd;&#xd65c;&#xc18c;&#xc74c;&#xc774; &#xbbfc;&#xc6d0; &#xbc1c;&#xc0dd;&#xc758; &#xc57d; 97%&#xb85c; &#xc18c;&#xc74c;&#xacf5;&#xd574; &#xb300;&#xbd80;&#xbd84;&#xc744; &#xcc28;&#xc9c0;"/>
<node CREATED="1596449630705" ID="ID_1214701953" MODIFIED="1596449747524" TEXT="&#xc0dd;&#xd65c; &#xc18c;&#xc74c; &#xc885;&#xb958;">
<node CREATED="1596449647419" HGAP="27" ID="ID_1843801568" MODIFIED="1596450037558" TEXT="&#xc0ac;&#xc5c5;&#xc7a5; &#xc18c;&#xc74c;" VSHIFT="-3"/>
<node CREATED="1596449658311" ID="ID_1479539014" MODIFIED="1596449660642" TEXT="&#xd655;&#xc131;&#xae30; &#xc18c;&#xc74c;"/>
<node CREATED="1596449749760" ID="ID_1978408172" MODIFIED="1596449751526" TEXT="&#xc774;&#xb3d9; &#xc18c;&#xc74c;"/>
<node CREATED="1596449937792" ID="ID_1309526292" MODIFIED="1596449940426" TEXT="&#xce35;&#xac04; &#xc18c;&#xc74c;"/>
</node>
</node>
<node CREATED="1596449990796" ID="ID_1258573344" MODIFIED="1596449993817" TEXT="&#xacf5;&#xc7a5; &#xc18c;&#xc74c;"/>
<node CREATED="1596449995900" ID="ID_38567449" MODIFIED="1596450026213" TEXT="&#xad50;&#xd1b5; &#xc18c;&#xc74c;"/>
<node CREATED="1596449999004" ID="ID_1919975588" MODIFIED="1596450029787" TEXT="&#xd56d;&#xacf5;&#xae30; &#xc18c;&#xc74c;"/>
</node>
</node>
<node CREATED="1596448497123" ID="ID_1317243122" MODIFIED="1596448498109" TEXT="&#xb300;&#xcc45;">
<node CREATED="1596450124782" ID="ID_496077737" MODIFIED="1596450128173" TEXT=" &#xbc95;&#xc73c;&#xb85c; &#xaddc;&#xc81c;">
<node CREATED="1596450743759" FOLDED="true" ID="ID_969695843" MODIFIED="1596451120293" TEXT="&#xc81c;21&#xc870;(&#xc0dd;&#xd65c;&#xc18c;&#xc74c;&#xacfc; &#xc9c4;&#xb3d9;&#xc758; &#xaddc;&#xc81c;)">
<node CREATED="1596450756975" ID="ID_1724790262" MODIFIED="1596450772948" TEXT="&#x2460;&#xd2b9;&#xbcc4;&#xc790;&#xce58;&#xc2dc;&#xc7a5;&#x318d;&#xd2b9;&#xbcc4;&#xc790;&#xce58;&#xb3c4;&#xc9c0;&#xc0ac; &#xb610;&#xb294; &#xc2dc;&#xc7a5;&#x318d;&#xad70;&#xc218;&#x318d;&#xad6c;&#xccad;&#xc7a5;&#xc740; &#xc8fc;&#xbbfc;&#xc758; &#xc870;&#xc6a9;&#xd558;&#xace0; &#xd3c9;&#xc628;&#xd55c; &#xc0dd;&#xd65c;&#xd658;&#xacbd;&#xc744; &#xc720;&#xc9c0;&#xd558;&#xae30; &#xc704;&#xd558;&#xc5ec; &#xc0ac;&#xc5c5;&#xc7a5; &#xbc0f; &#xacf5;&#xc0ac;&#xc7a5; &#xb4f1;&#xc5d0;&#xc11c; &#xbc1c;&#xc0dd;&#xd558;&#xb294; &#xc18c;&#xc74c;&#x318d;&#xc9c4;&#xb3d9;(&#xc0b0;&#xc5c5;&#xb2e8;&#xc9c0;&#xb098; &#xadf8; &#xbc16;&#xc5d0; &#xd658;&#xacbd;&#xbd80;&#xb839;&#xc73c;&#xb85c; &#xc815;&#xd558;&#xb294; &#xc9c0;&#xc5ed;&#xc5d0;&#xc11c; &#xbc1c;&#xc0dd;&#xd558;&#xb294; &#xc18c;&#xc74c;&#xacfc; &#xc9c4;&#xb3d9;&#xc740; &#xc81c;&#xc678;&#xd558;&#xba70;, &#xc774;&#xd558; &quot;&#xc0dd;&#xd65c;&#xc18c;&#xc74c;&#x318d;&#xc9c4;&#xb3d9;&quot;&#xc774;&#xb77c; &#xd55c;&#xb2e4;)&#xc744; &#xaddc;&#xc81c;&#xd558;&#xc5ec;&#xc57c; &#xd55c;&#xb2e4;."/>
<node CREATED="1596450784672" ID="ID_1337036212" MODIFIED="1596450785292" TEXT="&#x2461;&#xc81c;1&#xd56d;&#xc5d0; &#xb530;&#xb978; &#xc0dd;&#xd65c;&#xc18c;&#xc74c;&#x318d;&#xc9c4;&#xb3d9;&#xc758; &#xaddc;&#xc81c;&#xb300;&#xc0c1; &#xbc0f; &#xaddc;&#xc81c;&#xae30;&#xc900;&#xc740; &#xd658;&#xacbd;&#xbd80;&#xb839;&#xc73c;&#xb85c; &#xc815;&#xd55c;&#xb2e4;."/>
</node>
<node CREATED="1596450745198" FOLDED="true" ID="ID_1719778249" MODIFIED="1596450828821" TEXT="&#xc81c;21&#xc870;&#xc758;2(&#xce35;&#xac04;&#xc18c;&#xc74c;&#xae30;&#xc900; &#xb4f1;)">
<node CREATED="1596450795459" ID="ID_1587706836" MODIFIED="1596450803760" TEXT="&#x2460; &#xd658;&#xacbd;&#xbd80;&#xc7a5;&#xad00;&#xacfc; &#xad6d;&#xd1a0;&#xad50;&#xd1b5;&#xbd80;&#xc7a5;&#xad00;&#xc740; &#xacf5;&#xb3d9;&#xc73c;&#xb85c; &#xacf5;&#xb3d9;&#xc8fc;&#xd0dd;&#xc5d0;&#xc11c; &#xbc1c;&#xc0dd;&#xb418;&#xb294; &#xce35;&#xac04;&#xc18c;&#xc74c;(&#xc778;&#xc811;&#xd55c; &#xc138;&#xb300; &#xac04; &#xc18c;&#xc74c;&#xc744; &#xd3ec;&#xd568;&#xd55c;&#xb2e4;. &#xc774;&#xd558; &#xac19;&#xb2e4;)&#xc73c;&#xb85c; &#xc778;&#xd55c; &#xc785;&#xc8fc;&#xc790; &#xbc0f; &#xc0ac;&#xc6a9;&#xc790;&#xc758; &#xd53c;&#xd574;&#xb97c; &#xcd5c;&#xc18c;&#xd654;&#xd558;&#xace0; &#xbc1c;&#xc0dd;&#xb41c; &#xd53c;&#xd574;&#xc5d0; &#xad00;&#xd55c; &#xbd84;&#xc7c1;&#xc744; &#xd574;&#xacb0;&#xd558;&#xae30; &#xc704;&#xd558;&#xc5ec; &#xce35;&#xac04;&#xc18c;&#xc74c;&#xae30;&#xc900;&#xc744; &#xc815;&#xd558;&#xc5ec; &#xc57c; &#xd55c;&#xb2e4;."/>
<node CREATED="1596450805454" ID="ID_1452506307" MODIFIED="1596450808928" TEXT="&#x2461; &#xc81c;1&#xd56d;&#xc5d0; &#xb530;&#xb978; &#xce35;&#xac04;&#xc18c;&#xc74c;&#xc758; &#xd53c;&#xd574; &#xc608;&#xbc29; &#xbc0f; &#xbd84;&#xc7c1; &#xd574;&#xacb0;&#xc744; &#xc704;&#xd558;&#xc5ec; &#xd544;&#xc694;&#xd55c; &#xacbd;&#xc6b0; &#xd658;&#xacbd;&#xbd80;&#xc7a5;&#xad00;&#xc740; &#xb300;&#xd1b5;&#xb839;&#xb839;&#xc73c;&#xb85c; &#xc815;&#xd558;&#xb294; &#xbc14;&#xc5d0; &#xb530;&#xb77c; &#xc804;&#xbb38;&#xae30;&#xad00;&#xc73c;&#xb85c; &#xd558;&#xc5ec;&#xae08; &#xce35;&#xac04;&#xc18c;&#xc74c;&#xc758; &#xce21;&#xc815;, &#xd53c;&#xd574;&#xc0ac;&#xb840;&#xc758; &#xc870;&#xc0ac;&#x318d;&#xc0c1;&#xb2f4; &#xbc0f; &#xd53c;&#xd574;&#xc870;&#xc815;&#xc9c0;&#xc6d0;&#xc744; &#xc2e4;&#xc2dc;&#xd558;&#xb3c4;&#xb85d; &#xd560; &#xc218; &#xc788;&#xb2e4;."/>
<node CREATED="1596450810050" ID="ID_661390103" MODIFIED="1596450814901" TEXT="&#x2462; &#xc81c;1&#xd56d;&#xc5d0; &#xb530;&#xb978; &#xce35;&#xac04;&#xc18c;&#xc74c;&#xc758; &#xbc94;&#xc704;&#xc640; &#xae30;&#xc900;&#xc740; &#xd658;&#xacbd;&#xbd80;&#xc640; &#xad6d;&#xd1a0;&#xad50;&#xd1b5;&#xbd80;&#xc758; &#xacf5;&#xb3d9;&#xbd80;&#xb839;&#xc73c;&#xb85c; &#xc815;&#xd55c;&#xb2e4;."/>
</node>
<node CREATED="1596450836592" FOLDED="true" ID="ID_478554006" MODIFIED="1596450870925" TEXT="&#xc81c;22&#xc870;(&#xd2b9;&#xc815;&#xacf5;&#xc0ac;&#xc758; &#xc0ac;&#xc804;&#xc2e0;&#xace0; &#xb4f1;)">
<node CREATED="1596450840413" ID="ID_1523631696" MODIFIED="1596450845027" TEXT="&#x2460;&#xc0dd;&#xd65c;&#xc18c;&#xc74c;&#x318d;&#xc9c4;&#xb3d9;&#xc774; &#xbc1c;&#xc0dd;&#xd558;&#xb294; &#xacf5;&#xc0ac;&#xb85c;&#xc11c; &#xd658;&#xacbd;&#xbd80;&#xb839;&#xc73c;&#xb85c; &#xc815;&#xd558;&#xb294; &#xd2b9;&#xc815;&#xacf5;&#xc0ac;&#xb97c; &#xc2dc;&#xd589;&#xd558;&#xb824;&#xb294; &#xc790;&#xb294; &#xd658;&#xacbd;&#xbd80;&#xb839;&#xc73c;&#xb85c; &#xc815;&#xd558;&#xb294; &#xbc14;&#xc5d0; &#xb530;&#xb77c; &#xad00;&#xd560; &#xd2b9;&#xbcc4;&#xc790;&#xce58;&#xc2dc;&#xc7a5;&#x318d;&#xd2b9;&#xbcc4;&#xc790;&#xce58;&#xb3c4;&#xc9c0;&#xc0ac; &#xb610;&#xb294; &#xc2dc;&#xc7a5;&#x318d;&#xad70;&#xc218;&#x318d;&#xad6c;&#xccad;&#xc7a5;&#xc5d0;&#xac8c; &#xc2e0;&#xace0;&#xd558;&#xc5ec;&#xc57c; &#xd55c;&#xb2e4;."/>
<node CREATED="1596450853367" ID="ID_805272534" MODIFIED="1596450854105" TEXT="&#x2461;&#xc81c;1&#xd56d;&#xc5d0; &#xb530;&#xb77c; &#xc2e0;&#xace0;&#xb97c; &#xd55c; &#xc790;&#xac00; &#xadf8; &#xc2e0;&#xace0;&#xd55c; &#xc0ac;&#xd56d; &#xc911; &#xd658;&#xacbd;&#xbd80;&#xb839;&#xc73c;&#xb85c; &#xc815;&#xd558;&#xb294; &#xc911;&#xc694;&#xd55c; &#xc0ac;&#xd56d;&#xc744; &#xbcc0;&#xacbd;&#xd558;&#xb824;&#xba74; &#xd2b9;&#xbcc4;&#xc790;&#xce58;&#xc2dc;&#xc7a5;&#x318d;&#xd2b9;&#xbcc4;&#xc790;&#xce58;&#xb3c4;&#xc9c0;&#xc0ac; &#xb610;&#xb294; &#xc2dc;&#xc7a5;&#x318d;&#xad70;&#xc218;&#x318d;&#xad6c;&#xccad;&#xc7a5;&#xc5d0;&#xac8c; &#xbcc0;&#xacbd;&#xc2e0;&#xace0;&#xb97c; &#xd558;&#xc5ec;&#xc57c; &#xd55c;&#xb2e4;.  &lt;&#xac1c;&#xc815; 2009. 6. 9., 2013. 8. 13.&gt;"/>
<node CREATED="1596450867648" ID="ID_1206053129" MODIFIED="1596450868629" TEXT="&#x2462; &#xc81c;1&#xd56d;&#xc5d0; &#xb530;&#xb978; &#xd2b9;&#xc815;&#xacf5;&#xc0ac;&#xb97c; &#xc2dc;&#xd589;&#xd558;&#xb824;&#xb294; &#xc790;&#xb294; &#xb2e4;&#xc74c; &#xac01; &#xd638;&#xc758; &#xc0ac;&#xd56d;&#xc744; &#xbaa8;&#xb450; &#xc900;&#xc218;&#xd558;&#xc5ec;&#xc57c; &#xd55c;&#xb2e4;.  &lt;&#xac1c;&#xc815; 2009. 6. 9.&gt;"/>
</node>
<node CREATED="1596450875230" FOLDED="true" ID="ID_1684591663" MODIFIED="1596450895776" TEXT="&#xc81c;22&#xc870;&#xc758;2(&#xacf5;&#xc0ac;&#xc7a5; &#xc18c;&#xc74c;&#xce21;&#xc815;&#xae30;&#xae30;&#xc758; &#xc124;&#xce58; &#xad8c;&#xace0;)">
<node CREATED="1596450886146" ID="ID_893769973" MODIFIED="1596450894333" TEXT="&#xd2b9;&#xbcc4;&#xc790;&#xce58;&#xc2dc;&#xc7a5;&#x318d;&#xd2b9;&#xbcc4;&#xc790;&#xce58;&#xb3c4;&#xc9c0;&#xc0ac; &#xb610;&#xb294; &#xc2dc;&#xc7a5;&#x318d;&#xad70;&#xc218;&#x318d;&#xad6c;&#xccad;&#xc7a5;&#xc740; &#xacf5;&#xc0ac;&#xc7a5;&#xc5d0;&#xc11c; &#xbc1c;&#xc0dd;&#xd558;&#xb294; &#xc18c;&#xc74c;&#xc744; &#xc801;&#xc815;&#xd558;&#xac8c; &#xad00;&#xb9ac;&#xd558;&#xae30; &#xc704;&#xd558;&#xc5ec; &#xd544;&#xc694;&#xd55c; &#xacbd;&#xc6b0;&#xc5d0;&#xb294; &#xacf5;&#xc0ac;&#xb97c; &#xc2dc;&#xd589;&#xd558;&#xb294; &#xc790;&#xc5d0;&#xac8c; &#xc18c;&#xc74c;&#xce21;&#xc815;&#xae30;&#xae30;&#xb97c; &#xc124;&#xce58;&#xd558;&#xb3c4;&#xb85d; &#xad8c;&#xace0;&#xd560; &#xc218; &#xc788;&#xb2e4;.  &lt;&#xac1c;&#xc815; 2013. 8. 13.&gt;"/>
</node>
<node CREATED="1596450937496" FOLDED="true" ID="ID_1705591239" MODIFIED="1596450957221" TEXT="&#xc81c;40&#xc870;(&#xbc29;&#xc74c;&#xc2dc;&#xc124;&#xc758; &#xc131;&#xb2a5;&#xacfc; &#xc124;&#xce58; &#xae30;&#xc900; &#xb4f1;)">
<node CREATED="1596450942178" ID="ID_1611845090" MODIFIED="1596450946918" TEXT="&#x2460;&#xc18c;&#xc74c;&#xc744; &#xbc29;&#xc9c0;&#xd558;&#xae30; &#xc704;&#xd558;&#xc5ec; &#xbc29;&#xc74c;&#xbcbd;&#x318d;&#xbc29;&#xc74c;&#xb9bc;(&#x9632;&#x97f3;&#x6797;)&#x318d;&#xbc29;&#xc74c;&#xb451; &#xb4f1;&#xc758; &#xbc29;&#xc74c;&#xc2dc;&#xc124;&#xc744; &#xc124;&#xce58;&#xd558;&#xb294; &#xc790;&#xb294; &#xcda9;&#xbd84;&#xd55c; &#xc18c;&#xb9ac;&#xc758; &#xcc28;&#xb2e8; &#xd6a8;&#xacfc;&#xb97c; &#xc5bb;&#xc744; &#xc218; &#xc788;&#xb3c4;&#xb85d; &#xc124;&#xacc4;&#x318d;&#xc2dc;&#xacf5;&#xd558;&#xc5ec;&#xc57c; &#xd55c;&#xb2e4;."/>
<node CREATED="1596450947939" ID="ID_1623335078" MODIFIED="1596450951781" TEXT="&#x2461;&#xc81c;1&#xd56d;&#xc5d0; &#xb530;&#xb978; &#xbc29;&#xc74c;&#xc2dc;&#xc124;&#xc758; &#xc131;&#xb2a5;&#x318d;&#xc124;&#xce58;&#xae30;&#xc900; &#xbc0f; &#xc131;&#xb2a5;&#xd3c9;&#xac00; &#xb4f1; &#xc0ac;&#xd6c4;&#xad00;&#xb9ac;&#xc5d0; &#xd544;&#xc694;&#xd55c; &#xc0ac;&#xd56d;(&#xc774;&#xd558; &quot;&#xc124;&#xce58;&#xae30;&#xc900;&#xb4f1;&quot;&#xc774;&#xb77c; &#xd55c;&#xb2e4;)&#xc740; &#xd658;&#xacbd;&#xbd80;&#xc7a5;&#xad00;&#xc774; &#xc815;&#xd558;&#xc5ec; &#xace0;&#xc2dc;&#xd560; &#xc218; &#xc788;&#xb2e4;. &#xb2e4;&#xb9cc;, &#xb2e4;&#xb978; &#xbc95;&#xb960;&#xc774; &#xbc29;&#xc74c;&#xc2dc;&#xc124;&#xc758; &#xc124;&#xce58;&#xae30;&#xc900;&#xb4f1;&#xc744; &#xb2ec;&#xb9ac; &#xc815;&#xd558;&#xace0; &#xc788;&#xc73c;&#xba74; &#xadf8; &#xc124;&#xce58;&#xae30;&#xc900;&#xb4f1;&#xc5d0; &#xb530;&#xb978;&#xb2e4;.  &lt;&#xac1c;&#xc815; 2009. 6. 9.&gt;"/>
</node>
</node>
<node CREATED="1596450131807" ID="ID_1485437432" MODIFIED="1596450135720" TEXT="&#xc790;&#xc728;&#xc801; &#xd574;&#xacb0; &#xbc29;&#xc548;">
<node CREATED="1596451036902" ID="ID_1092529053" MODIFIED="1596451041510" TEXT="&#xc2dc;&#xbbfc; &#xc758;&#xc2dd; &#xac15;&#xd654; &#xd544;&#xc694;"/>
</node>
</node>
</node>
</node>
</map>
